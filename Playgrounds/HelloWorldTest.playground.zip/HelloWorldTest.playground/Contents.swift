import Cocoa
import SwiftUI

var greeting = "Hello, World  "
var name = "Noah Carpenter"

let Address = "Home"

var myage = 10
var yourage = 12
var ourAge = myage + yourage

print (greeting + "My name is \(name)," + "our ages together are \(ourAge)")

print (10 + 35)
