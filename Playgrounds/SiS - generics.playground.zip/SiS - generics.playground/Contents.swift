func compareValues<T: Comparable>(_ a: T, _ b: T) -> Bool {
    return a > b
}
