let score = 100
print("Score: \(score) 🌟")
