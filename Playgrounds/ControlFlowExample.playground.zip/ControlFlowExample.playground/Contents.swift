let temperature = 65

if temperature >= 65 && temperature <= 75 {
  print("The temperature is just right.")
} else if temperature < 65 {
  print("It's too cold.")
} else {
  print("It's too hot.")
}

