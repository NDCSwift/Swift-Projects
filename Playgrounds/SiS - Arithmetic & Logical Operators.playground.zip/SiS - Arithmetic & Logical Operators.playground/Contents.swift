let bothTrue = (5 > 3) && (3 < 5)   // Output: true
let oneTrue = (5 > 3) || (3 > 5)    // Output: true

