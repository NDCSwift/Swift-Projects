let number = 10 // Swift infers number is of type Int
let newNumber:Int = 10

let pi = 3.14

var name = "Alice"


if  name is Int {
    print("String")
}
else
{
    print("not a string")
}
