

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Welcome to your profile")
    }
}

#Preview {
    ProfileView()
}
