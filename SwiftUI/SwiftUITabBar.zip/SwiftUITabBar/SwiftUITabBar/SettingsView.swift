

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Welcome to settings")
    }
}

#Preview {
    SettingsView()
}
