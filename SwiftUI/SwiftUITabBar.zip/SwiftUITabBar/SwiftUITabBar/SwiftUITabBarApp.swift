

import SwiftUI

@main
struct SwiftUITabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
