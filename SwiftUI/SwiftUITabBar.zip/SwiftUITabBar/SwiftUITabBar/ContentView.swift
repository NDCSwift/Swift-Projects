//
//  ContentView.swift
//  SwiftUITabBar
//
//  Created by Noah Carpenter on 2024-01-31
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI

// ContentView struct is the main view that contains the TabView and its associated views.
struct ContentView: View {
    var body: some View {
        // TabView allows us to create a tab-based navigation system
        TabView {
            // HomeView for the Home tab with a house icon
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            // ProfileView for the Profile tab with a person icon
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.fill")
                }
            
            // SettingsView for the Settings tab with a gear icon
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear.circle.fill")
                }
            
            // LeaderboardView for the Leaderboard tab with a clipboard icon
            LeaderboardView()
                .tabItem {
                    Label("LeaderBoard", systemImage: "list.clipboard.fill")
                }
            
            // GameView for the Games tab with a game controller icon
            GameView()
                .tabItem {
                    Label("Games", systemImage: "gamecontroller.fill")
                }
            
            // OnlineView for the Online tab with a globe icon
            OnlineView()
                .tabItem {
                    Label("Online", systemImage: "globe")
                }
        }
        .accentColor(.purple) // Change the accent color for selected tabs
    }
}

// Preview to show the ContentView in Xcode's preview pane
#Preview {
    ContentView()
}
