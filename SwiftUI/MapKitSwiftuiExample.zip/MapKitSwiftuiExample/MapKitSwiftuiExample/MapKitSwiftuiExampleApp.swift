
import SwiftUI

@main
struct MapKitSwiftuiExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
