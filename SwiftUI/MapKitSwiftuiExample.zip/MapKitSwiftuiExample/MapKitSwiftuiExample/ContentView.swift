//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI
import CoreLocation
import MapKit

// MARK: - LocationManager

/// A class responsible for managing location updates and authorization.
class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    // Core Location Manager instance
    private let locationManager = CLLocationManager()
    
    // Published property to update the map region in the UI
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 49.25064, longitude: 123.20666),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    
    // Initializer to set up the location manager
    override init() {
        super.init()
        locationManager.delegate = self // Assign delegate to receive location updates
        locationManager.requestWhenInUseAuthorization() // Request location permission from the user
        locationManager.startUpdatingLocation() // Start receiving location updates
    }
    
    // CLLocationManagerDelegate method to handle location updates
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latestLocation = locations.last else { return }
        // Update the region to center on the latest location
        DispatchQueue.main.async {
            self.region = MKCoordinateRegion(
                center: latestLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            )
        }
    }
    
    // CLLocationManagerDelegate method to handle authorization changes
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.startUpdatingLocation() // Start updating location if authorized
        case .denied, .restricted:
            print("Location access denied or restricted.")
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization() // Request authorization if not determined
        @unknown default:
            break
        }
    }
}

// Extension to make MKPointAnnotation conform to Identifiable protocol
extension MKPointAnnotation: Identifiable {
    public var id: UUID {
        UUID() // Generates a unique identifier for each annotation
    }
}

// MARK: - ContentView

/// The main view that displays a map with user location and allows adding pins via long press.
struct ContentView: View {
    // StateObject to manage and observe location updates
    @StateObject private var locationManager = LocationManager()
    
    // State property to hold the list of map pins
    @State private var pins: [MKPointAnnotation] = []
    
    var body: some View {
        ZStack {
            // Map view displaying the user's location and pins
            Map(coordinateRegion: $locationManager.region, showsUserLocation: true, annotationItems: pins) { pin in
                // Customizing the appearance of each pin
                MapPin(coordinate: pin.coordinate, tint: .purple)
            }
            .gesture(
                // Adding a long press gesture to add a new pin
                LongPressGesture(minimumDuration: 1.0)
                    .onEnded { _ in
                        let newPin = MKPointAnnotation()
                        newPin.coordinate = locationManager.region.center // Set pin at the center of the current region
                        pins.append(newPin) // Add the new pin to the list
                    }
            )
            .frame(height: 400) // Sets the height of the map view
        }
        .padding() // Adds padding around the ZStack
    }
}

// MARK: - Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
