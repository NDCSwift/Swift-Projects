//  NotificationExampleSwiftUIApp.swift
//  NotificationExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-11-19.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI
import UserNotifications

// MARK: - NotificationExampleSwiftUIApp

/// The main entry point of the NotificationExampleSwiftUI app.
/// Sets up the notification center delegate to handle user interactions with notifications.
@main
struct NotificationExampleSwiftUIApp: App {
    // Initialize the NotificationHandler to manage notification responses
    @UIApplicationDelegateAdaptor(NotificationHandler.self) var notificationHandler
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - NotificationHandler

/// A class that handles notification responses and conforms to UNUserNotificationCenterDelegate.
class NotificationHandler: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    /// Called when the app has finished launching.
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {
        // Set the notification center delegate to self
        UNUserNotificationCenter.current().delegate = self
        return true
    }
    
    /// Handles user interactions with notifications.
    /// - Parameters:
    ///   - center: The notification center that received the response.
    ///   - response: The user's response to the notification.
    ///   - completionHandler: The block to execute when the handling is complete.
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        switch response.actionIdentifier {
        case "MARK_AS_DONE":
            print("User marked task as done")
        
        case "SNOOZE":
            print("User snoozed the task")
        
        case "ADD_NOTE":
            // Handle the text input from the user
            if let textResponse = response as? UNTextInputNotificationResponse {
                let note = textResponse.userText
                print("User added Note: \(note)")
            }
        
        default:
            break
        }
        completionHandler()
    }
}
