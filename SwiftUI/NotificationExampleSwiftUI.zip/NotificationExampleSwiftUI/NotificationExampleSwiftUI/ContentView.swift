//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI
import UserNotifications

// MARK: - ContentView

/// The main view that provides buttons to request notification permissions,
/// schedule standard notifications, and schedule interactive notifications.
struct ContentView: View {
    var body: some View {
        VStack(spacing: 30) {
            // Button to request notification permissions from the user
            Button("Request Notification Permission") {
                requestNotificationPermission()
            }
            .buttonStyle(.borderedProminent)
            
            // Button to schedule a standard notification
            Button("Schedule Notification") {
                scheduleNotification()
            }
            .buttonStyle(.borderedProminent)
            
            // Button to schedule an interactive notification with actions
            Button("Schedule Interactive Notification") {
                setupNotificationCategory(withTextInput: true) // Set up the notification category
                scheduleInteractiveNotification() // Schedule the interactive notification
            }
            .buttonStyle(.automatic)
        }
        .padding() // Adds padding around the VStack
    }
    
    // MARK: - Notification Setup Functions
    
    /// Sets up the notification categories with actions.
    /// - Parameter withTextInput: Determines if a text input action should be included.
    func setupNotificationCategory(withTextInput: Bool = false) {
        // Define the "Mark as Done" action
        let markAsDone = UNNotificationAction(
            identifier: "MARK_AS_DONE",
            title: "Mark as Done",
            options: [.foreground]
        )
        
        // Define the "Snooze" action
        let snooze = UNNotificationAction(
            identifier: "SNOOZE",
            title: "Snooze",
            options: []
        )
        
        // Define the "Add Note" text input action
        let addNote = UNTextInputNotificationAction(
            identifier: "ADD_NOTE",
            title: "Add Note",
            options: [],
            textInputButtonTitle: "Submit",
            textInputPlaceholder: "Type your note here"
        )
        
        // Define the notification category with the above actions
        let category = UNNotificationCategory(
            identifier: "TASK_CATEGORY",
            actions: [markAsDone, snooze, addNote],
            intentIdentifiers: [],
            options: []
        )
        
        // Register the notification categories with the notification center
        UNUserNotificationCenter.current().setNotificationCategories([category])
    }
    
    /// Requests notification permissions from the user.
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("Permission granted")
            } else if let error = error {
                print("Error: \(error.localizedDescription)")
            } else {
                print("Permission Denied")
            }
        }
    }
    
    /// Schedules a standard notification to be delivered after a specified time interval.
    func scheduleNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Friendly Reminder"
        content.body = "Don't forget to do your chores."
        content.sound = .default
        
        // Trigger the notification after 5 seconds
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        
        // Create the notification request
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        
        // Add the notification request to the notification center
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled successfully.")
            }
        }
    }
    
    /// Schedules an interactive notification with custom actions.
    func scheduleInteractiveNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Task Reminder"
        content.body = "Your task is waiting for you."
        content.sound = .default
        content.categoryIdentifier = "TASK_CATEGORY" // Link the category to enable actions
        
        // Trigger the notification after 10 seconds
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        
        // Create the notification request
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        
        // Add the notification request to the notification center
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling interactive notification: \(error.localizedDescription)")
            } else {
                print("Interactive Notification scheduled successfully.")
            }
        }
    }
}

// MARK: - Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
