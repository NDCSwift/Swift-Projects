

import SwiftUI

@main
struct SwiftUIStacksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
