
import SwiftUI

@main
struct SwiftUICounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
