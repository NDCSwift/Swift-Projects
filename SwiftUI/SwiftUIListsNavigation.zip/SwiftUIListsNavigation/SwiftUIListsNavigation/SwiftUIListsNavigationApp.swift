
import SwiftUI

@main
struct SwiftUIListsNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
