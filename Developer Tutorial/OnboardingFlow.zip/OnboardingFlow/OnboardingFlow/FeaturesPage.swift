//  FeaturesPage.swift
//  OnboardingFlow
//
//  Created by Noah Carpenter on 2024-12-24.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// MARK: - FeaturesPage

/// A view that displays a list of feature cards, each highlighting a different feature of the app.
/// This page is part of the onboarding flow, providing users with insights into what the app offers.
struct FeaturesPage: View {
    var body: some View {
        VStack(spacing: 30) {
            // Title for the Features page
            Text("Features")
                .font(.title)             // Sets the font size to title
                .fontWeight(.semibold)    // Sets the font weight to semibold
                .padding(.bottom)         // Adds padding below the text
                .padding(.top, 100)       // Adds extra padding at the top
            
            // First feature card with detailed description
            FeatureCard(
                iconName: "person.2.crop.square.stack.fill",
                description: "A multiline description about a feature paired with an image it wants us to test long text"
            )
            
            // Second feature card with a short summary
            FeatureCard(
                iconName: "applepencil",
                description: "Short Summary"
            )
            
            Spacer() // Pushes the content to the top
        }
        .padding() // Adds padding around the VStack
    }
}

// MARK: - Preview

struct FeaturesPage_Previews: PreviewProvider {
    static var previews: some View {
        FeaturesPage()
            .frame(maxHeight: .infinity)                        // Expands the frame to the maximum height
            .background(Gradient(colors: gradientColors))        // Sets the same gradient background as ContentView
            .foregroundStyle(.white)                             // Sets the foreground color to white
    }
}
