//  WelcomePage.swift
//  OnboardingFlow
//
//  Created by Noah Carpenter on 2024-12-24.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// MARK: - WelcomePage

/// The initial welcome screen of the onboarding flow.
/// Displays a welcoming icon, the app name, and a brief description.
struct WelcomePage: View {
    var body: some View {
        VStack {
            ZStack {
                // Rounded rectangle background for the icon
                RoundedRectangle(cornerRadius: 50)
                    .frame(width: 200, height: 200)          // Sets the size of the rectangle
                    .foregroundStyle(.tint)                  // Applies the tint color
                
                // Icon representing the welcome message
                Image(systemName: "figure.2.and.child.holdinghands")
                    .font(.system(size: 100))                // Sets the font size to 100
                    .foregroundStyle(.white)                  // Sets the icon color to white
            }
            
            // App title
            Text("Welcome to MyApp")
                .font(.largeTitle)                         // Sets the font size to largeTitle
                .fontWeight(.bold)                         // Makes the text bold
                .padding(.top)                             // Adds padding at the top
            
            // App description
            Text("Description Text")
                .multilineTextAlignment(.center)           // Centers the text
                .font(.title2)                             // Sets the font size to title2
        }
        .padding()                                        // Adds padding around the VStack
    }
}

// MARK: - Preview

struct WelcomePage_Previews: PreviewProvider {
    static var previews: some View {
        WelcomePage()
    }
}
