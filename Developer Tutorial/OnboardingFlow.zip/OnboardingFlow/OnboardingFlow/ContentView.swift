//  ContentView.swift
//  OnboardingFlow
//
//  Created by Noah Carpenter on 2024-12-24.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// Define gradient colors used in the background
let gradientColors: [Color] = [
    .gradientTop,     // Custom color defined elsewhere in the project
    .gradientBottom   // Custom color defined elsewhere in the project
]

// MARK: - ContentView

/// The main view that manages the onboarding flow using a TabView.
/// It contains the WelcomePage and FeaturesPage, providing a seamless onboarding experience.
struct ContentView: View {
    var body: some View {
        TabView {
            WelcomePage()    // The first page of the onboarding flow
            FeaturesPage()   // The second page showcasing app features
        }
        .background(Gradient(colors: gradientColors)) // Sets a gradient background for the TabView
        .tabViewStyle(.page)                            // Applies a page-style tab view
        .foregroundStyle(.white)                        // Sets the foreground color to white
    }
}

// MARK: - Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
