//  FeatureCard.swift
//  OnboardingFlow
//
//  Created by Noah Carpenter on 2024-12-24.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// MARK: - FeatureCard

/// A reusable card view that displays an icon and a description of a feature.
/// This view is used within the FeaturesPage to showcase different app features.
struct FeatureCard: View {
    let iconName: String       // The name of the system image to display
    let description: String    // The description text for the feature
    
    var body: some View {
        HStack {
            // Displays the feature icon
            Image(systemName: iconName)
                .font(.largeTitle)               // Sets the font size to large
                .frame(width: 50)                // Sets a fixed width for the icon
                .padding(.trailing, 10)          // Adds padding to the trailing edge
            
            // Displays the feature description
            Text(description)
            
            Spacer() // Pushes the content to the leading edge
        }
        .padding() // Adds padding around the HStack
        .background {
            // Sets a rounded rectangle as the background with specific styling
            RoundedRectangle(cornerRadius: 12)
                .foregroundStyle(.tint)     // Applies the tint color
                .opacity(0.25)               // Sets the opacity to make it slightly transparent
                .brightness(-0.4)            // Darkens the background
        }
        .foregroundStyle(.white) // Sets the foreground color to white for text and icons
    }
}

// MARK: - Preview

struct FeatureCard_Previews: PreviewProvider {
    static var previews: some View {
        // Example preview with sample data
        FeatureCard(
            iconName: "person.2.crop.square.stack.fill",
            description: "A multiline description about a feature paired with an image it wants us to test long text"
        )
    }
}
