

import SwiftUI

@main
struct OnboardingFlowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
