//  Created by Noah Carpenter
   //  🐱 Follow me on YouTube! 🎥
   //  https://www.youtube.com/@NoahDoesCoding97
   //  Like and Subscribe for coding tutorials and fun! 💻✨
   //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
   //  Dream Big, Code Bigger

import SwiftUI

struct ContentView: View {
    // State property to store and manage username input
    @State private var username = ""
    
    var body: some View {
        NavigationStack{
            ZStack {
                GradientBackground() // adds animated gradient to our contentView
                VStack {
                    
                    Image("profileImage") // displays image from assets
                        .resizable() // allows image to be resized to fit the frame
                        .aspectRatio(contentMode: .fill) // maintains aspect ratio while filling frame
                        .frame(width: 200, height: 200) // sets fixed dimensions
                        .clipShape(Circle())//clip our image to a circular shape
                        .overlay(
                            Circle().stroke(Color.purple, lineWidth: 5) // Adds a purple border around the circular image
                        )
                        .shadow(radius: 5) // adds drop shadow effect
                    
                    
                    Text("Home Page")
                    NavigationLink(destination: DetailView()) {
                        CustomButton(title: "Go to Details") {}
                    }
                    
                    CustomTextField(text: $username, placeholder: "Enter your Name") // Custom text input field with binding to username state
                    
                }
                .padding() // adds padding around the VStack content
            }
        }
    }
}

#Preview {
    ContentView()
}
