//  Created by Noah Carpenter
   //  🐱 Follow me on YouTube! 🎥
   //  https://www.youtube.com/@NoahDoesCoding97
   //  Like and Subscribe for coding tutorials and fun! 💻✨
   //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
   //  Dream Big, Code Bigger

import SwiftUI

struct CustomTextField: View {
    @Binding var text: String // Binding to pass and update text externally
    var placeholder: String // placeholder text
    
    
    var body: some View {
        TextField(placeholder, text: $text) // showing placeholder until the user types
            .padding() // add padding inside textfield
            .background(Color.gray.opacity(0.2)) // set light gray background in textfield
            .cornerRadius(25) // rounds the corners of the textfield
            .font(.custom("AvenirNext-Regular", size: 16)) // uses custom font and size
            .padding(.horizontal)
    }
}

