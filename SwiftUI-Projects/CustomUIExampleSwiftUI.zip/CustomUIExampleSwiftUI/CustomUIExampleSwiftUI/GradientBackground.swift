//  Created by Noah Carpenter
   //  🐱 Follow me on YouTube! 🎥
   //  https://www.youtube.com/@NoahDoesCoding97
   //  Like and Subscribe for coding tutorials and fun! 💻✨
   //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
   //  Dream Big, Code Bigger

import SwiftUI

struct GradientBackground: View {
    @State private var animateGradient = false // Track the animation state for gradient movement
    var body: some View {
        LinearGradient(colors: [Color.purple, Color.orange], startPoint: animateGradient ? .topLeading : .bottomTrailing, endPoint: animateGradient ? .bottomTrailing : .topLeading) // gradient from purple to orange
            .edgesIgnoringSafeArea(.all) // extend gradient to cover entire screen
            .onAppear{
                // toggle gradient animation with smooth transistions
                withAnimation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true)){
                    animateGradient.toggle()
                }
            }


    }
}

#Preview {
    GradientBackground()
}
