//
//  SwiftUIViewLibrary.swift
//  SwiftUI View Library Demo
//
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI
import Charts

/// **Main ContentView showcasing the SwiftUI View Library features.**
struct ContentView: View {
    
    /// State variable to store user's input name
    @State private var name: String = ""
    
    var body: some View {

            
            NavigationView {
                ZStack {
                    LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing)
                        .ignoresSafeArea(.all)
                        .opacity(0.25)
                    VStack(spacing: 20) { // ✅ VStack arranges content vertically
                        // 📌 Title Text with Custom Font & Color
                        Text("Welcome to SwiftUI!")
                            .font(.largeTitle)
                            .foregroundColor(.orange)
                            .bold()
                            .italic()
                        
                        // 📌 Display an SF Symbol Image
                        Image(systemName: "bird.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.orange)
                            .shadow(radius: 10)
                           
                        
                        // 📌 TextField for User Input
                        TextField("Enter your name", text: $name)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                        
                        // 📌 Button with Custom Styling
                        Button(action: {
                            print("Button tapped!") // ✅ Debugging: Print message on tap
                        }) {
                            Text("Press Me")
                                .padding()
                                .frame(maxWidth: .infinity) // ✅ Expands button width
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .padding(.horizontal)
                        
                        // 📌 Navigation Link to DetailsView
                        NavigationLink(destination: DetailsView(userName: name)) {
                            Text("Go to Details")
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .padding(.horizontal)
                        
                        Spacer() // ✅ Pushes content to top
                    }
                    .padding()
                    .navigationTitle("SwiftUI Library")
                   
                } // ✅ Adds a title to the navigation bar
            }
        
    }
}

/// **DetailsView to display user-entered name and list example**
struct DetailsView: View {
    var userName: String
    
    var body: some View {
        VStack {
            // 📌 Display User Name (if entered)
            if !userName.isEmpty {
                Text("Hello, \(userName)!")
                    .font(.title)
                    .padding()
            }
            
            // 📌 List Example
            List {
                Section(header: Text("SwiftUI Components")) {
                    Text("Text View")
                    Text("Image View")
                    Text("Button")
                    Text("TextField")
                }
            }
        }
        .navigationTitle("Details") // ✅ Adds navigation title
    }
}

#Preview {
    ContentView()
}
