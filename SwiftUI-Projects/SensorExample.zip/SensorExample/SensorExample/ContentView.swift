//
//  ContentView.swift
//  SensorExample
//
//  Created by Noah Carpenter on 2024-12-05
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI
import CoreMotion // Allows access to device sensors

// MotionManager class to handle accelerometer and gyroscope updates
class MotionManager: ObservableObject {
    private let motion = CMMotionManager() // Core motion manager instance
    @Published var accelerometerData: CMAccelerometerData? // Published data for SwiftUI updates
    @Published var gyroscopeData: CMGyroData? // Published gyroscope data for SwiftUI updates
    
    init() {
        startAcceleromoterUpdates() // Start accelerometer updates
        startGyroscopeUpdates() // Start gyroscope updates
    }

    // Function to start accelerometer updates
    func startAcceleromoterUpdates() {
        if motion.isAccelerometerAvailable {
            motion.accelerometerUpdateInterval = 0.1 // Updates every 0.1 seconds
            motion.startAccelerometerUpdates(to: .main) { [weak self] data, error in
                if let data = data {
                    self?.accelerometerData = data // Update accelerometer data
                }
            }
        }
    }

    // Function to start gyroscope updates
    func startGyroscopeUpdates() {
        if motion.isGyroAvailable {
            motion.gyroUpdateInterval = 0.1 // Updates every 0.1 seconds
            motion.startGyroUpdates(to: .main) { [weak self] data, error in
                if let data = data {
                    self?.gyroscopeData = data // Update gyroscope data
                }
            }
        }
    }
}

// Main ContentView structure
struct ContentView: View {
    @StateObject private var motionManager = MotionManager() // StateObject to manage motion updates

    var body: some View {
        VStack(spacing: 20) {
            // Display Accelerometer Data
            Text("Accelerometer Data")
                .font(.headline)
            
            if let data = motionManager.accelerometerData {
                Text("X: \(data.acceleration.x, specifier: "%.2f")")
                Text("Y: \(data.acceleration.y, specifier: "%.2f")")
                Text("Z: \(data.acceleration.z, specifier: "%.2f")")
            } else {
                Text("No motion found")
            }
            
            // Display Gyroscope Data
            Text("Gyroscope Data")
                .font(.headline)
                .foregroundStyle(Color.purple)
            
            if let gyroData = motionManager.gyroscopeData {
                Text("X: \(gyroData.rotationRate.x, specifier: "%.2f")")
                    .foregroundStyle(Color.purple)
                Text("Y: \(gyroData.rotationRate.y, specifier: "%.2f")")
                    .foregroundStyle(Color.purple)
                Text("Z: \(gyroData.rotationRate.z, specifier: "%.2f")")
                    .foregroundStyle(Color.purple)
            } else {
                Text("Gyro not found")
                    .foregroundStyle(Color.red)
            }
        }
        .padding() // Add padding to the VStack for layout purposes
    }
}

#Preview {
    ContentView()
}
