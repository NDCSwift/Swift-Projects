

import SwiftUI

@main
struct SensorExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
