import SwiftUI

/// **Chat View - Receives a Username & Supports Modal + Full-Screen Calls**
struct ChatView: View {
    let username: String
    @State private var showSendSheet = false
    @State private var showCallScreen = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Chat with \(username)")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.blue)
            
            // 📌 Button to open a sheet modal for sending images
            Button(action: {
                withAnimation {
                    showSendSheet.toggle()
                }
            }) {
                Label("Send Image", systemImage: "photo")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .foregroundColor(.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .shadow(radius: 5)
            }
            .padding(.horizontal)
            
            // 📌 Button to open a full-screen modal for calling
            Button(action: {
                withAnimation {
                    showCallScreen.toggle()
                }
            }) {
                Label("Start Call", systemImage: "phone.fill")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.2))
                    .foregroundColor(.green)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .shadow(radius: 5)
            }
            .padding(.horizontal)
        }
        .padding()
        .sheet(isPresented: $showSendSheet) {
            SendImageView()
        }
        .fullScreenCover(isPresented: $showCallScreen) {
            CallView(username: username)
        }
        .navigationTitle(username)
        
    }
}

#Preview {
    ChatView(username: "SwiftUser")
}
