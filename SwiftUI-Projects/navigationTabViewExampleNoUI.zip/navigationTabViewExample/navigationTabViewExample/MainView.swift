//
//  MainView.swift
//  SwiftUINavigationExample
//
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Dream Big, Code Bigger
//

import SwiftUI

/// **Main TabView that organizes the app into multiple sections**
struct MainView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill") // ✅ Home screen tab
                }
            
            NavigationStack {
                ProfileView()
            }
            .tabItem {
                Label("Profile", systemImage: "person.fill") // ✅ Profile screen tab
            }
        }
    }
}

#Preview {
    MainView()
}
