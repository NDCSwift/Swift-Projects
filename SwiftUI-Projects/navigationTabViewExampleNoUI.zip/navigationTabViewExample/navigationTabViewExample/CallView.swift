//
    // Project: navigationTabViewExample
    //  File: CallView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI

/// **Full-Screen Call View**
struct CallView: View {
    @Environment(\.dismiss) var dismiss
    let username: String
    
    var body: some View {
        VStack {
            Text("Voice Call in Progress... 📞")
                .font(.largeTitle)
            
            Button("End Call") {
                dismiss() // ✅ Closes full-screen modal
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

#Preview {
    CallView(username: "SwiftUser")
}