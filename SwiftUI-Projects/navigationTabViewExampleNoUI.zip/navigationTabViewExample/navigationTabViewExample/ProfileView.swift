//
    // Project: navigationTabViewExample
    //  File: ProfileView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI

/// **Profile Screen that links to a Chat Feature**
struct ProfileView: View {
    var body: some View {
        NavigationStack { // ✅ Allows deeper navigation
            VStack {
                Text("Profile Screen")
                    .font(.largeTitle)
                
                // 📌 Navigation to Chat Screen with username passed
                NavigationLink(destination: ChatView(username: "SwiftUser")) {
                    Text("Go to Chat")
                        .padding()
                        .buttonStyle(.borderedProminent)
                }
            }
            .navigationTitle("Profile")
        }
    }
}

#Preview {
    ProfileView()
}