//
    // Project: Toasts&Snackbars
    //  File: InlineMessageForm.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
import SwiftUI

struct InlineMessageForm: View {
    @State private var name = ""
    @State private var showError = false

    var body: some View {
        Form {
            Section("Profile") {
                TextField("Name", text: $name)
                if showError && name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    HStack(spacing: 8) {
                        Image(systemName: "exclamationmark.circle.fill")
                            .foregroundStyle(.red)
                        Text("Name can’t be empty.")
                            .foregroundStyle(.red)
                            .font(.footnote)
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel(Text("Error: Name can’t be empty."))
                }
            }

            Button("Save") {
                showError = name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                // Otherwise perform save…
            }
        }
        .navigationTitle("Edit Profile")
    }
}

#Preview {
    InlineMessageForm()
}
