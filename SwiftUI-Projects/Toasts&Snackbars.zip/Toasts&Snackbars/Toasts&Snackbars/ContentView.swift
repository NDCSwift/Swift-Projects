//
    // Project: Toasts&Snackbars
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    @State private var showToast = false
    
    var body: some View {
        ZStack {
            // Main content
            VStack(spacing: 16) {
                Text("Manual Toast Demo")
                    .font(.title2).bold()
                
                Button("Save Item") {
                    showToastWithAutoHide()
                }
                .buttonStyle(.borderedProminent)
                
                Spacer()
            }
            .padding()
            
            // Toast overlay
            if showToast {
                ToastView(
                    title: "Saved!",
                    systemImage: "checkmark.circle.fill",
                    tint: .green
                )
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .zIndex(1)
            }
        }
        // Smooth in/out
        .animation(.spring(response: 0.35, dampingFraction: 0.9), value: showToast)
    }
    
    private func showToastWithAutoHide() {
        showToast = true
        // Auto-hide after 2 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            showToast = false
        }
    }
}

#Preview {
    ContentView()
}
