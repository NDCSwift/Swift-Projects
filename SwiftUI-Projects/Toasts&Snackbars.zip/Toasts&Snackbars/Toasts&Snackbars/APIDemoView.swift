//
    // Project: Toasts&Snackbars
    //  File: LibraryDemoView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import AlertToast

struct APIDemoView: View {
    @State private var success = false
    @State private var error = false
    @State private var warning = false
    
    var body: some View {
        VStack(spacing: 12) {
            Button("Show Success") { success = true }.buttonStyle(.borderedProminent)
            Button("Show Error") { error = true }.buttonStyle(.bordered)
            Button("Show Warning") { warning = true }.buttonStyle(.bordered)
            
            Spacer()
        }
        .padding()
        .toast(isPresenting: $success) {
            AlertToast(type: .complete(.green), title: "Uploaded!")
        }
        .toast(isPresenting: $error) {
            AlertToast(type: .error(.red), title: "Delete failed", subTitle: "Try again later")
        }
        .toast(isPresenting: $warning, alert: {
            AlertToast(displayMode: .hud, type: .systemImage("exclamationmark.triangle.fill", .yellow),
                       title: "Low Storage")
        })
    }
}

#Preview {
    APIDemoView()
}
