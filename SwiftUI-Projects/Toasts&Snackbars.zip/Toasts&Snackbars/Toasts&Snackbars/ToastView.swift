//
    // Project: Toasts&Snackbars
    //  File: ToastView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI

struct ToastView: View {
    var title: String
    var systemImage: String = "info.circle.fill"
    var tint: Color = .blue

    var body: some View {
        VStack {
            Spacer()
            HStack(spacing: 12) {
                Image(systemName: systemImage)
                    .imageScale(.large)
                Text(title)
                    .font(.callout.weight(.semibold))
                    .lineLimit(2)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundStyle(.white)
            .background(tint.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(radius: 12, y: 6)
            .padding(.horizontal, 16)
            .padding(.bottom, 24) // bottom placement
            .accessibilityElement(children: .combine)
            .accessibilityLabel(Text(title))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        .allowsHitTesting(false) // don't block taps behind
    }
}