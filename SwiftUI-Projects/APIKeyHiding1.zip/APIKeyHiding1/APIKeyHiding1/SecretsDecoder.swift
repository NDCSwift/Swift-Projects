//
    // Project: APIKeyHiding1
    //  File: Untitled.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
import Foundation

enum Secrets{
    static var weatherAPIKey: String {
        guard let key = Bundle.main.infoDictionary?["WEATHER_API_KEY"] as? String else{
            fatalError("Weather API Key not found in Check Secrets.xcconfig")
        }
        return key
    }
}
