//
    // Project: APIKeyHiding1
    //  File: WeatherViewModel.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import Foundation
class WeatherViewModel: ObservableObject {
    
    @Published var temperature: String = "Loading..."
    
    func fetchWeather(){
        let city = "London"
        let key = Secrets.weatherAPIKey
        let urlStr = "https://api.weatherapi.com/v1/current.json?key=\(key)&q=\(city)"
        
        
        guard let url = URL(string: urlStr) else{
            temperature = "Invalid URL"
            return
        }
        
        URLSession.shared.dataTask(with: url){ data, _, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.temperature = "Error \(error.localizedDescription)"
                }
                return
            }
            guard let data = data else{
                DispatchQueue.main.async {
                    self.temperature = "No Data Recived"
                }
                return
            }
            
            if let decoded = try? JSONDecoder().decode(WeatherResponse.self, from: data) {
                DispatchQueue.main.async {
                    self.temperature = "\(decoded.current.temp_c)°C in \(decoded.location.name)"
                }
            } else {
                // Debugging only
                print("Decoding failed. Raw response:")
                print(String(data: data, encoding: .utf8) ?? "Unreadable")
                
                DispatchQueue.main.async {
                    self.temperature = "Failed to decode response"
                }
            }
        }.resume()
    }

}

struct WeatherResponse: Decodable{
    struct Location: Decodable { let name: String }
    struct Current: Decodable { let temp_c: Double}
    
    let location: Location
    let current: Current
}
