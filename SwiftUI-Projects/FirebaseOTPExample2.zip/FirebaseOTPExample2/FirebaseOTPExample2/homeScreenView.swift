//
    // Project: FirebaseOTPExample2
    //  File: homeScreenView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct homeScreenView: View {
    var body: some View {
        Text("Welcome to the app!")
            .font(.largeTitle)
            .bold()
            .multilineTextAlignment(.center)
    }
}

#Preview {
    homeScreenView()
}
