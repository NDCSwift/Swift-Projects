//  ContentView.swift
//  PearlButtonExample
//
//  Created by Noah Carpenter on 2024-10-29.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// MARK: - ContentView

/// The main view that displays a welcome message and two PearlButtons.
/// One button prints a message when tapped, and the other navigates to the SettingsView.
struct ContentView: View {
    var body: some View {
        NavigationStack { // Provides navigation capabilities
            VStack { // Stacks the views vertically
                // Displays a welcome message
                Text("Welcome To our App")
                    .font(.largeTitle) // Sets the font to large title
                
                // Custom PearlButton that prints a message when tapped
                PearlButton(title: "Get Started") {
                    print("Get started Tapped") // Action to perform when the button is tapped
                }
                
                // NavigationLink that navigates to SettingsView when the button is tapped
                NavigationLink(destination: SettingsView()) {
                    PearlButton(title: "Go to settings") {
                        // Empty action since NavigationLink handles the navigation
                    }
                }
            }
            .padding() // Adds padding around the VStack
        }
    }
}

// MARK: - Preview

#Preview {
    ContentView()
}
