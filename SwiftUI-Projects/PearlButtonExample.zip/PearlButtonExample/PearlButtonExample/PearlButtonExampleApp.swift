

import SwiftUI

@main
struct PearlButtonExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
