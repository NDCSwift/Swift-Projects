//  PearlButton.swift
//  PearlButtonExample
//
//  Created by Noah Carpenter on 2024-10-29.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// MARK: - PearlButton

/// A custom button view with a gradient background.
/// It displays a title and executes a closure when tapped.
struct PearlButton: View {
    
    let title: String // The text displayed on the button
    var action: () -> Void // The closure to execute when the button is tapped
    
    
    var body: some View {
        Button(action: action) { // Defines the button's action
            Text(title) // Displays the button's title
                .font(.headline) // Sets the font to headline
                .padding() // Adds padding around the text
                .frame(maxWidth: .infinity) // Makes the button take up the maximum available width
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [Color("PearlStart"), Color("PearlEnd")]), // Defines a linear gradient background
                        startPoint: .topLeading, // Gradient starts from the top leading corner
                        endPoint: .bottomTrailing // Gradient ends at the bottom trailing corner
                    )
                )
                .cornerRadius(25) // Rounds the corners of the button
        }
    }
}

// MARK: - Preview

//#Preview {
//    PearlButton()
//}
