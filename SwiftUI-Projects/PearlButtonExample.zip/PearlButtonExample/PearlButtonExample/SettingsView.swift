

import SwiftUI

struct SettingsView: View {
    var body: some View {
        
        PearlButton(title: "Change Theme")
        {
            print("Theme changed")
        }
        PearlButton(title: "Increase FontSize"){
            print("font button pressed")
        }
    }
}

#Preview {
    SettingsView()
}
