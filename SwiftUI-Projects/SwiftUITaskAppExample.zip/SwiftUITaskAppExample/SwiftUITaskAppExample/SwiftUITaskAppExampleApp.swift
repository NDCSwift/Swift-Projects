//
//  SwiftUITaskAppExampleApp.swift
//  SwiftUITaskAppExample
//
//  Created by Noah Carpenter on 2024-11-05.
//

import SwiftUI

@main
struct SwiftUITaskAppExampleApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
