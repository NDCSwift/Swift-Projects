//
//  ContentView.swift
//  SwiftUITaskAppExample
//
//  Created by Noah Carpenter on 2024-11-05.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
// fetch request to retrive all of our toDoItems and sort them by the date created
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \ToDoItem.dateCreated, ascending: true)],
        animation: .default)
    private var toDoItems: FetchedResults<ToDoItem>
    
    // State var to store the new task title
    @State private var newTaskTitle: String = ""

    var body: some View {
        NavigationView {
            VStack{
                // textfield to have users enter a new task
                TextField("Enter your new task", text: $newTaskTitle)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                //Add a button to add the new task
                Button(action: addTask){
                    Label("add task", systemImage: "plus")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                Button(action: deleteAllTasks){
                    Label("DELETE EVERYTHING", systemImage: "minus")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                
                
                .padding(.horizontal)
                List {
                    ForEach(toDoItems) { item in
                        VStack {
                            Text(item.title ?? "Untitled Task")
                                .font(.headline)
                            Text(item.dateCreated ?? Date(), formatter: itemFormatter)
                            
                        }
                        
                    }
                    .onDelete(perform: deleteTask) // Swipe to Delete individual tasks
                }
            }
            .navigationTitle("To-Do List")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
            }
        }
    }
// MARKL - Core Data Operations
        // add a new task to Core Data
    private func addTask() {
        withAnimation {
            let newTask = ToDoItem(context: viewContext)
            newTask.title = newTaskTitle
            newTask.dateCreated = Date()

            do {
                try viewContext.save()
                newTaskTitle = ""
            } catch {
                print("Error Saving Tasks \(error)")
            }
        }
    }

    private func deleteTask(offsets: IndexSet) {
        withAnimation {
            offsets.map { toDoItems[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                print("Failed to delete \(error)")
            }
        }
    }
        private func deleteAllTasks(){
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = ToDoItem.fetchRequest()
            let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
            do {
                try viewContext.save()
                try viewContext.execute(deleteRequest)
         
                
            } catch{
                print("Error deleting all tasks! \(error)")
            }
        }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
