//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// View for editing the user's profile information
struct EditProfileView: View {
    // @AppStorage property wrapper for persisting username across app launches
    @AppStorage("username") private var username: String = ""
    
    
    var body: some View {
        // Main vertical stack container
        VStack{
            // Title for the edit screen
            Text("Edit Username")
                .font(.largeTitle)
                .fontWeight(.bold)
            // Text input field for updating username
            TextField("Enter your username", text: $username)
                .padding()
            // Informative text about persistence
            Text("Username will be saved across launches")
                .font(.subheadline)
                .italic()
                .underline()
                .foregroundStyle(Color.blue)
        }
        // Sets the navigation bar title
        .navigationTitle("Edit Profile")
    }
}

#Preview {
    EditProfileView()
}
