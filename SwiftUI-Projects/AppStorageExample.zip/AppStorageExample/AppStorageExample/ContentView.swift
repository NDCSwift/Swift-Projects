//  Created by Noah Carpenter
   //  🐱 Follow me on YouTube! 🎥
   //  https://www.youtube.com/@NoahDoesCoding97
   //  Like and Subscribe for coding tutorials and fun! 💻✨
   //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
   //  Dream Big, Code Bigger
import SwiftUI

// Main view structure that handles the user interface
struct ContentView: View {
    // @AppStorage property wrapper allows persistent storage of data across app launches
    // Stores the username with a default value of empty string
    @AppStorage("username") private var username: String = ""
    // Stores the user's score with a default value of 0
    @AppStorage("score") private var score: Int = 0
    
    
    
    var body: some View {
        // NavigationView enables navigation capabilities in the app
        NavigationView{
            VStack {
                // Welcome text that shows either the username or "Guest" if username is empty
                Text("Welcome, \(username.isEmpty ? "Guest" : username)!")
                    .font(.largeTitle)
                    .padding()
                
                // Displays the current score
                Text("Score \(score)")
                    .font(.title)
                    .padding()
                
                // Navigation link to the EditProfileView for updating username
                NavigationLink(destination: EditProfileView()) {
                    Text("Edit Profile")
                        .font(.headline)
                        .padding()
                        .background(Color.purple)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                // Button to increase the score by 1
                Button(action: {
                    score += 1
                }) {
                    Text("Increase Score")
                        .font(.headline)
                        .padding()
                        .background(Color.green)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                // Button to decrease the score by 1
                Button(action: {
                    score -= 1
                }) {
                    Text("Decrease Score")
                        .font(.headline)
                        .padding()
                        .background(Color.red)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
