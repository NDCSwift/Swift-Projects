//
    // Project: ProgressView_Gauge
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
import SwiftUI

struct ContentView: View {
    @State private var speed: Double = 10
    
    var speedColor: Color {
        switch speed {
        case 0...60:
            return .green
        case 60...90:
            return .yellow
        default:
            return .red
        }
    }
    
    var body: some View {
        VStack(spacing: 40) {
            Gauge(value: speed, in: 0...120) {
                Text("Speed")
            } currentValueLabel: {
                Text("\(Int(speed)) km/h")
            }
            .gaugeStyle(.accessoryCircular)
            .tint(speedColor)
            .padding()
            .scaleEffect(4.0)
            .frame(width: 200, height: 200)
            
            Image(systemName: "square.and.arrow.up.fill")
            
    
        }
    }
}

#Preview {
    ContentView()
}
