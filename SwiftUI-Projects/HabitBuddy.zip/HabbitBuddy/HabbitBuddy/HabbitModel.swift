//
    // Project: HabbitBuddy
    //  File: HabbitModel.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftData
import Foundation

@Model
class Habit {
    var title: String
    var details: String?
    var createdAt: Date
    var progress: [Date] // store the completed days
    
    //init the new habit with a title and optional details
    
    init(title: String, details: String? = nil) {
        self.title = title
        self.details = details
        self.createdAt = Date()
        self.progress = []
    }
}
