//
    // Project: HabbitBuddy
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import SwiftData

//display the list of habits and allows users to add new ones
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext // SwiftData Context
    @Query private var habits: [Habit] // fetch habits stored in swift data
    
    @State private var showingAddHabit = false // handle the showing of the habit adding sheet
    
    var body: some View {
        NavigationView{
            List{
                ForEach(habits){ habit in
                    NavigationLink(destination: HabitDetailView(habit: habit)){
                        VStack(alignment: .leading){
                            Text(habit.title)
                                .font(.headline)
                            if let details = habit.details{
                                Text(details)
                                    .font(.subheadline)
                                    .foregroundStyle(.gray)
                            }
                            
                        }
                    }
                    
                }
                .onDelete(perform: deleteHabit)
            }
            .navigationTitle("My Habbits")
            .toolbar {
                Button(action: { showingAddHabit = true}){
                    Label("Add Habbit", systemImage: "plus.circle.fill")
                }
            }
            .sheet(isPresented: $showingAddHabit){
                HabitFormView()
            }
        }
    }
    private func deleteHabit(at offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(habits[index])
        }
    }
}

#Preview {
    ContentView()
}
