//
    // Project: HabbitBuddy
    //  File: HabitFormView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import SwiftData

// a form for adding a new habit

struct HabitFormView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss // allows dismissing the sheet
    
    @State private var habitName: String = "" // store the user input
    @State private var habitDetails: String = ""
    
    var body: some View {
        NavigationView {
            Form{
                Section(header: Text("Habit name")){
                    TextField("Enter Habit Name", text: $habitName)
                        .textFieldStyle(.roundedBorder)
                }
                Section(header: Text("Details (Optional)")){
                    TextEditor(text: $habitDetails)
                        .frame(height: 100)
                        .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.gray))
                }
                Section{
                    Button("Save Habit"){
                        saveHabit()
                    }
                    .disabled(habitName.isEmpty)
                }
            }
            .navigationTitle("New Habit")
            .toolbar{
                ToolbarItem(placement: .cancellationAction){
                    Button("Cancel"){
                        dismiss()
                    }
                }
            }
        }
    }
    private func saveHabit(){
        let newHabit = Habit(title: habitName, details: habitDetails.isEmpty ? nil : habitDetails)
        modelContext.insert(newHabit) // add the habit to swift data
        dismiss()
    }
}

#Preview {
    HabitFormView()
}
