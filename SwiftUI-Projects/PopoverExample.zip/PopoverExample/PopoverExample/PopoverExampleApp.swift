

import SwiftUI

@main
struct PopoverExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
