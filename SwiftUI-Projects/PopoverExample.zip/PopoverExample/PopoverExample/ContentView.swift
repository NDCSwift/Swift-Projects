//
//  ContentView.swift
//  PopoverExample
//
//  Created by Noah Carpenter on 2024-11-13
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI

struct ContentView: View {
    // State to control if the delete alert is shown
    @State private var showAlert = false
    // State to control if the popover is shown
    @State private var showPopover = false
    // State to hold the selected item for viewing or deletion
    @State private var selectedItem: String? = nil
    // List of items to be displayed
    @State private var items = ["apples", "bananas", "cherries"]
    
    var body: some View {
        VStack {
            // List to display items with swipe actions and long press gesture
            List(items, id: \.self) { item in
                Text(item)
                    // Long press gesture to show the popover
                    .onLongPressGesture {
                        selectedItem = item
                        showPopover = true
                    }
                    .swipeActions {
                        // Swipe action to delete item with confirmation
                        Button(role: .destructive) {
                            selectedItem = item
                            showAlert = true
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
            }
            // Alert for confirming the deletion of an item
            .alert("Delete Item?", isPresented: $showAlert) {
                Button("Delete", role: .destructive) {
                    deleteItems(selectedItem)
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure you want to delete \(selectedItem ?? "this item")?")
            }
        }
        .popover(isPresented: $showPopover) {
            VStack(spacing: 20) {
                // Display the details of the selected item in the popover
                Text(selectedItem ?? "Item Details")
                    .font(.title2)
                    .padding()
                // Button to close the popover
                Button("Close") {
                    showPopover = false
                }
                .padding()
                .background(Color.red)
                .foregroundStyle(Color.white)
            }
            .padding()
            .frame(width: 250, height: 250)
        }
        .padding()
    }
    
    // Function to delete the selected item from the list
    private func deleteItems(_ item: String?) {
        if let item = item, let index = items.firstIndex(of: item) {
            items.remove(at: index)
        }
    }
}

#Preview {
    ContentView()
}
