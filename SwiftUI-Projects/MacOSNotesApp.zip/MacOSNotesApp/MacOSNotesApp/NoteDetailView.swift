//
    // Project: MacOSNotesApp
    //  File: NoteDetailView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct NoteDetailView: View {
    @Binding var note: Note
    var body: some View {
        VStack(alignment: .leading){
            TextField("Title", text: $note.title)
                .font(.title)
                .padding(.bottom)
            TextEditor(text: $note.body)
                .font(.body)
                .border(Color.white.opacity(0.5))
            
        }
        .padding()
        .navigationTitle(note.title)
    }
}

#Preview {
    @State var sampleNote = Note(title: "preview", body: "Preview body")
    NoteDetailView(note: $sampleNote)
}
