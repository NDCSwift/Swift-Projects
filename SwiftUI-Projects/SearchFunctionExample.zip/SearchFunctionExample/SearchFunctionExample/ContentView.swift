//
//  ContentView.swift
//  SearchFunctionExample
//
//  Created by Noah Carpenter on 2024-11-19
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI

struct ContentView: View {
    // List of items that will be displayed in the search results
    @State private var items = ["Apples", "Bananas", "Cherries", "Dates", "Elderberries"]
    
    // User's current search term entered in the search bar
    @State private var searchTerm = ""
    
    // Filtered list of items based on the search term
    var filteredItems: [String] {
        if searchTerm.isEmpty {
            // Return all items if no search term is entered
            return items
        } else {
            // Filter items based on the search term, ignoring case
            return items.filter { $0.localizedCaseInsensitiveContains(searchTerm) }
        }
    }
    
    var body: some View {
        VStack {
            // TextField for user input, allowing search functionality
            TextField("Search Items...", text: $searchTerm)
                .textFieldStyle(RoundedBorderTextFieldStyle()) // Style the text field
                .padding() // Add padding around the text field
            
            // List to display the filtered items based on search term
            List(filteredItems, id: \.self) { item in
                Text(item) // Display each filtered item
            }
        }
        .padding() // Add padding to the whole VStack
    }
}

#Preview {
    ContentView()
}
