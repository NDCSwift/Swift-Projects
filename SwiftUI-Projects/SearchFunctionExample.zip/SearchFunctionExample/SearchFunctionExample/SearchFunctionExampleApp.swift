

import SwiftUI

@main
struct SearchFunctionExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
