//
    // Project: CameraZoom
    //  File: CameraView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI
import AVFoundation

struct CameraView: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    
    func makeUIViewController(context: Context) -> CameraViewController {
        let cameraVC = CameraViewController()
        cameraVC.delegate = context.coordinator
        return cameraVC
    }
    
    func updateUIViewController(_ uiViewController: CameraViewController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, CameraViewControllerDelegate {
        let parent: CameraView
        
        init(_ parent: CameraView) {
            self.parent = parent
        }
        
        func didCapture(image: UIImage) {
            parent.image = image
        }
    }
}

protocol CameraViewControllerDelegate: AnyObject {
    func didCapture(image: UIImage)
}

class CameraViewController: UIViewController, AVCapturePhotoCaptureDelegate {
    var captureSession: AVCaptureSession!
    var photoOutput: AVCapturePhotoOutput!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var captureDevice: AVCaptureDevice!
    weak var delegate: CameraViewControllerDelegate?
    
    let zoomLevels: [CGFloat] = [1.0, 2.0, 0.5] // 1x, 2x, 0.5x
    var currentZoomLevelIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupUI()
    }
    
    func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo

        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("No camera found")
            return
        }

        captureDevice = device

        do {
            let input = try AVCaptureDeviceInput(device: captureDevice)
            captureSession.addInput(input)
        } catch {
            print("Error setting up camera input: \(error)")
            return
        }

        photoOutput = AVCapturePhotoOutput()
        captureSession.addOutput(photoOutput)

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = view.bounds
        view.layer.addSublayer(previewLayer)

        
        DispatchQueue.global(qos: .userInitiated).async {
            self.captureSession.startRunning()
        }
    }
    
    func setupUI() {
        let captureButton = UIButton(frame: CGRect(x: (view.frame.width - 80) / 2, y: view.frame.height - 100, width: 80, height: 80))
        captureButton.backgroundColor = .white
        captureButton.layer.cornerRadius = 40
        captureButton.layer.borderColor = UIColor.black.cgColor
        captureButton.layer.borderWidth = 3
        captureButton.addTarget(self, action: #selector(capturePhoto), for: .touchUpInside)
        view.addSubview(captureButton)
        
        let zoomButton = UIButton(frame: CGRect(x: view.frame.width - 100, y: view.frame.height - 100, width: 80, height: 40))
        zoomButton.setTitle("Zoom", for: .normal)
        zoomButton.backgroundColor = .gray
        zoomButton.layer.cornerRadius = 10
        zoomButton.addTarget(self, action: #selector(changeZoom), for: .touchUpInside)
        view.addSubview(zoomButton)
    }
    
    @objc func capturePhoto() {
        let settings = AVCapturePhotoSettings()
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
    
    @objc func changeZoom() {
        currentZoomLevelIndex = (currentZoomLevelIndex + 1) % zoomLevels.count
        let newZoomFactor = zoomLevels[currentZoomLevelIndex]
        
        do {
            try captureDevice.lockForConfiguration()
            
            // Ensure zoom is within valid range
            let minZoom = 1.0
            let maxZoom = captureDevice.activeFormat.videoMaxZoomFactor
            let validZoomFactor = max(minZoom, min(newZoomFactor, maxZoom))
            
            captureDevice.videoZoomFactor = validZoomFactor
            captureDevice.unlockForConfiguration()
            
            print("Zoom set to: \(validZoomFactor)") // Debugging output
        } catch {
            print("Failed to set zoom: \(error)")
        }
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard let data = photo.fileDataRepresentation(), let image = UIImage(data: data) else { return }
        delegate?.didCapture(image: image)
        dismiss(animated: true)
    }
}
