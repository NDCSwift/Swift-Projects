//
    // Project: ActivityViewExample
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import UIKit

enum ShareType: String, CaseIterable{
    case text, url, image
    
    func content(using username: String) -> [Any]{
        switch self {
        case .text:
            return ["SwitUI is awesome - \(username)"]
        case .url:
            return [URL(string: "https://www.youtube.com/@NoahDoesCoding97")!]
        case .image:
            if let image = UIImage(systemName: "star.fill"){
                return [image]
            }
            else {
                return ["(no image available)"]
            }
        }
    }
}

struct ContentView: View {
    @State private var showShareSheet = false
    
    @State private var username = ""
    
    @State private var selectedItemToShare: ShareType = .text
    
    @State private var shareContent: [Any] = ["Hello from swiftUI"]
    
    var body: some View {
        NavigationView {
            VStack {
                
                Picker("Share Type", selection: $selectedItemToShare){
                    ForEach(ShareType.allCases, id:  \.self){
                        type in
                        Text(type.rawValue.capitalized)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                
                TextField("Enter your name to share", text: $username)
                    .textFieldStyle(.roundedBorder)
                
                Button("Update Share Content"){
                    shareContent = selectedItemToShare.content(using: username)
                }
                
                Button{
                    showShareSheet = true
                    
                } label: {
                    Label("share", systemImage:  "square.and.arrow.up")
                        .font(.title2)
                        .padding()
                        .background(Color.purple)
                        .foregroundStyle(.white)
                        .cornerRadius(15)
                }
                
                
            }
            .padding()
            .navigationTitle("Sharing")
            
            .sheet(isPresented: $showShareSheet){
                ShareSheet(activityItems: shareContent)
            }
        }
    }
}

#Preview {
    ContentView()
}
