//
    // Project: FormTemplate
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            // Custom background for the entire screen
            Color.blue.opacity(0.2).edgesIgnoringSafeArea(.all)
            
            VStack {

                Form {
                    Section ("Sign Up") {
                        TextField("Name", text: .constant(""))
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                        
                        TextField("Email", text: .constant(""))
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10) // Optional: round corners for TextField
                    }
                    .listRowBackground(Color.clear)
                    
                    Section {
                        Button("Submit") {
                          
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .frame(maxWidth: .infinity)
                    }
                }
                .scrollContentBackground(.hidden)
                

                
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}

