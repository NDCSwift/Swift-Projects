//
    // Project: AlertsDemo
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    @State private var showSheet = false
    
    var body: some View {
        Button("Show custom bottom sheet") { showSheet = true }
            .sheet(isPresented: $showSheet) {
                VStack(spacing: 16) {
                    Capsule().frame(width: 40, height: 5).opacity(0.3) // mini drag indicator
                    Text("Delete workout?")
                        .font(.headline)
                    Text("This can’t be undone.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    
                    Button(role: .destructive) {
                        // delete
                        showSheet = false
                    } label: {
                        Label("Delete", systemImage: "trash")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    
                    Button {
                        showSheet = false
                    } label: {
                        Text("Cancel")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
                .presentationDetents([.height(360)]) // or [.medium, .large]
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(22)
            }
    }
}


#Preview {
    ContentView()
}
