//
    // Project: SwiftUI Text&Label
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {

                // MARK: - 1. The "How": Quick Implementation & Bare Bones

                Group {
                    Text("1. The \"How\": Quick Implementation & Bare Bones")
                        .font(.headline)
                        .padding(.bottom, 5)

                    // Basic Text
                    Text("Basic Text:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Welcome to my App!")
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)

                    Text("This is a simple description of the main feature.")
                        .padding(.horizontal)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(8)


                    // Basic Label
                    Text("Basic Label (SF Symbols):")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Label("Settings", systemImage: "gearshape.fill")
                        .padding()
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(8)

                    Label("Profile", systemImage: "person.crop.circle.fill")
                        .padding()
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)
                }
                .padding(.horizontal)


                Divider()

                // MARK: - 2. The "Power-Up": Essential Customization & Common Use Cases

                Group {
                    Text("2. The \"Power-Up\": Essential Customization & Common Use Cases")
                        .font(.headline)
                        .padding(.bottom, 5)

                    // Text Modifiers
                    Text("Text Modifiers:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    Text("App Title")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.accentColor)

                    Text("A longer paragraph of text that needs to wrap and align nicely.")
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .foregroundColor(.secondary)

                    Text("Custom Font Example")
                        .font(.custom("AvenirNext-Bold", size: 24)) // Ensure this font is available on your system via Font Book
                        .padding(.vertical, 5)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(8)

                    Text("This is a very long sentence that needs to be truncated because it won't fit on one line.")
                        .lineLimit(1)
                        .truncationMode(.tail)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)

                    Text("Some text that might be too long.")
                        .lineLimit(2)
                        .truncationMode(.head)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)

                    Text("Long title that might not fit in a small space")
                        .font(.title)
                        .minimumScaleFactor(0.5) // Allows text to shrink to 50% of its original size
                        .lineLimit(1)
                        .frame(width: 250, height: 50, alignment: .leading)
                        .border(Color.red)
                        .background(Color.gray.opacity(0.1))


                    Text("Important Information").bold()
                    Text("A phrase to emphasize").italic()
                    Text("Underlined text").underline()
                    Text("Deleted item").strikethrough()


                    // Label Customization
                    Text("Label Customization:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    Label("Default Style", systemImage: "star.fill")
                        .padding(.vertical, 5)
                        .background(Color.blue.opacity(0.1)).cornerRadius(8)
                    Label("Title Only", systemImage: "heart.fill")
                        .labelStyle(.titleOnly)
                        .padding(.vertical, 5)
                        .background(Color.blue.opacity(0.1)).cornerRadius(8)
                    Label("Icon Only", systemImage: "sun.max.fill")
                        .labelStyle(.iconOnly)
                        .padding(.vertical, 5)
                        .background(Color.blue.opacity(0.1)).cornerRadius(8)
                    Label("Title and Icon", systemImage: "cloud.fill")
                        .labelStyle(.titleAndIcon)
                        .padding(.vertical, 5)
                        .background(Color.blue.opacity(0.1)).cornerRadius(8)

                    // Label with Custom Asset Image
                    Text("Label with Custom Asset Image:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    // Make sure you have an image named "CustomDownloadIcon" in your Assets.xcassets
                    Label {
                        Text("Downloads")
                            .font(.title3)
                            .foregroundColor(.green)
                    } icon: {
                        // Ensure "downloads" is in your Assets.xcassets
                        // For demo, if you don't have this, replace with Image(systemName: "square.and.arrow.down.fill")
                        Image("downloads")
                            .resizable()
                            .frame(width: 40, height: 40)
                    }
                    .padding()
                    .background(Color.yellow.opacity(0.1))
                    .cornerRadius(8)


                    // Formatting Data with Text
                    Text("Formatting Data with Text:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(Date(), format: .dateTime)
                    Text(Date(), format: .dateTime.month(.wide).day().year())
                    Text(123.45, format: .currency(code: "USD"))
                    Text(987654321, format: .number)
                }
                .padding(.horizontal)

                Divider()

                // MARK: - 3. The "Pro Tip" & "Gotchas": Advanced Insights & Common Pitfalls

                Group {
                    Text("3. The \"Pro Tip\" & \"Gotchas\": Advanced Insights & Common Pitfalls")
                        .font(.headline)
                        .padding(.bottom, 5)

                    // Markdown in Text
                    Text("Markdown in Text:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Hello *World*! This is **bold** and `code`.")
                        .padding(.vertical, 5)
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)
                    Text("List item 1\n- Item A\n- Item B") // Basic list via newline
                        .padding(.vertical, 5)
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)


                    // Label vs. Manual HStack (Image + Text)
                    Text("Label vs. Manual HStack (for Accessibility):")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    HStack {
                        Image(systemName: "lightbulb.fill")
                        Text("Tips & Tricks (HStack)")
                    }
                    .padding(.vertical, 5)
                    .background(Color.indigo.opacity(0.1))
                    .cornerRadius(8)

                    Label("Tips & Tricks (Label)", systemImage: "lightbulb.fill")
                        .padding(.vertical, 5)
                        .background(Color.indigo.opacity(0.1))
                        .cornerRadius(8)

                    Text("Note: VoiceOver will read the Label as a single, combined element for better accessibility.")
                        .font(.caption)
                        .foregroundColor(.gray)


                    // Dynamic Type Considerations
                    Text("Dynamic Type Considerations:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("This text will adapt to your system's Dynamic Type settings.")
                        .font(.largeTitle) // Use system font styles for automatic scaling
                        .minimumScaleFactor(0.8) // Can still apply if needed for tight layouts
                        .lineLimit(1)
                        .padding(.vertical, 5)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(8)
                    Text("Adjust text size in your device's Accessibility settings to see this in action.")
                        .font(.caption)
                        .foregroundColor(.gray)

                    // Accessibility Labels (Conceptual)
                    Text("Accessibility Labels (Conceptual):")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Text views inherently provide their text as accessibility labels.")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text("Labels combine their text and image into a single, semantic accessibility element for VoiceOver.")
                        .font(.caption)
                        .foregroundColor(.gray)

                }
                .padding(.horizontal)

                Spacer() // Pushes content to top if short
            }
            .padding(.vertical)
        }
        .navigationTitle("Text & Label Masterclass")
    }
}


#Preview {
    ContentView()
}
