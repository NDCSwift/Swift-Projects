//
    // Project: AnimationsExample1
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

/// A simple example of using `withAnimation` to animate a state change.
struct SimpleAnimationView: View {
    @State private var isExpanded = false

    var body: some View {
        VStack {
            Rectangle()
                .fill(isExpanded ? Color.blue : Color.green)
                .frame(width: 100, height: isExpanded ? 200 : 100) // ✅ Animated height change
                .cornerRadius(10)
                .animation(.default, value: isExpanded) // ✅ Implicit animation
            
            Button("Toggle") {
                withAnimation {
                    isExpanded.toggle()
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

#Preview {
    SimpleAnimationView()
}
