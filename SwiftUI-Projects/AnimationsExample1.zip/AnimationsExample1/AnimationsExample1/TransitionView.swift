//
    // Project: AnimationsExample1
    //  File: TransitionView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI

/// Demonstrates SwiftUI transitions with animations.
struct TransitionView: View {
    @State private var showBox = false

    var body: some View {
        VStack {
            if showBox {
                Rectangle()
                    .fill(Color.orange)
                    .frame(width: 150, height: 150)
                    .cornerRadius(10)
                    .transition(.slide) // ✅ Smooth slide transition
                    .animation(.easeOut(duration: 0.5), value: showBox)
            }

            Button("Toggle Box") {
                withAnimation {
                    showBox.toggle()
                }
            }
        }
    }
}

#Preview{
    TransitionView()
}
