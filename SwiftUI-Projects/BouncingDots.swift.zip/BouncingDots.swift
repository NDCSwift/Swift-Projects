import SwiftUI

struct BouncingDots: View {
    let count = 3
    let size: CGFloat = 12
    let spacing: CGFloat = 8
    var body: some View {
        TimelineView(.animation) { timeline in
            let time = timeline.date.timeIntervalSinceReferenceDate
            HStack(spacing: spacing) {
                ForEach(0..<count) { index in
                    Circle()
                        .fill(.blue)
                        .frame(width: size, height: size)
                        .offset(y: bounceOffset(for: index, time: time))
                }
            }
        }
    }

    func bounceOffset(for index: Int, time: TimeInterval) -> CGFloat {
        let delay = Double(index) * 0.2
        return sin((time + delay) * 4) * 10
    }
}

#Preview {
    BouncingDots()
}
