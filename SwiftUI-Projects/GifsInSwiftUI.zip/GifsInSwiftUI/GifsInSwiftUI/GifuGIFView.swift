//
    // Project: GifsInSwiftUI
    //  File: GifuGIFView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import SwiftUI
import Gifu

struct GifuGIFView: UIViewRepresentable {
    let name: String

    func makeUIView(context: Context) -> GIFImageView {
        let imageView = GIFImageView()
        imageView.animate(withGIFNamed: name)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }

    func updateUIView(_ uiView: GIFImageView, context: Context) {}
}

struct ContentView: View {
    var body: some View {
        GifuGIFView(name: "catspin")
            .frame(width: 200, height: 200)
    }
}

#Preview{
    ContentView()
}
