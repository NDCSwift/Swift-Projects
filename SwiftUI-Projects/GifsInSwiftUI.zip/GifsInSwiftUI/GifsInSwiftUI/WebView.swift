//
    // Project: GifsInSwiftUI
    //  File: Untitled.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import WebKit

struct WebGIFView: UIViewRepresentable {
    let url: URL
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.scrollView.isScrollEnabled = false
        webView.load(URLRequest(url: url))
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WebViewShowcase: View {
    var body: some View {
        Text("Hard at work")
            .font(.title)
        WebGIFView(url: URL(string: "https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.gif")!)
            .frame(width: 300, height: 300)
    }
}

#Preview{
    WebViewShowcase()
}
