//
    // Project: Colors_Shapes
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue, Color.orange, Color.purple]), startPoint: .leading, endPoint: .trailing)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                
                Rectangle()
                    .fill(LinearGradient(gradient: Gradient(colors: [Color.orange.opacity(0.5), Color.appColor1.opacity(0.53)]), startPoint: .top, endPoint: .center))
                    .stroke(.black, lineWidth: 1)
                    .frame(width: 250, height: 250)
                    .cornerRadius(12)
                    .rotationEffect(.degrees(45))
                    .shadow(color: .red, radius: 10)
                    .padding(.bottom, 100)
                
                    Circle()
                    .fill(Color(#colorLiteral(red: 1, green: 0.9990146756, blue: 0, alpha: 1)))
                    .frame(width: 100)
                

                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
