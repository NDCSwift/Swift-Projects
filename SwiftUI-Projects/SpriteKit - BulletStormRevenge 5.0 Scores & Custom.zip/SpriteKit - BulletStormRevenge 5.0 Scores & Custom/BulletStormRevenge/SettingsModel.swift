//
    // Project: BulletStormRevenge
    //  File: GameSettings.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    


import Foundation
import SwiftData

@Model
class GameSettings {
    var bgmEnabled: Bool
    var sfxEnabled: Bool
    var selectedShipColor: String

    init(bgmEnabled: Bool = true, sfxEnabled: Bool = true, selectedShipColor: String = "silver") {
        self.bgmEnabled = bgmEnabled
        self.sfxEnabled = sfxEnabled
        self.selectedShipColor = selectedShipColor
    }
}