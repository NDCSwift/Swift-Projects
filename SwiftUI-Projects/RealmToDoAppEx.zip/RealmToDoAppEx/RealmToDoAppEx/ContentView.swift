//
// Project: RealmToDoAppEx
//  File: ContentView.swift
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI
import RealmSwift

struct ContentView: View {
    // Observes live updates to the list of ToDoItem objects in Realm
    @ObservedResults(ToDoItem.self) var todoItems
    // Stores the text input for creating a new task
    @State private var newTask = ""

    var body: some View {
        NavigationView {
            VStack {
                // UI for adding a new task
                HStack {
                    TextField("New Task", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("Add") {
                        // Adds the new task to the Realm list and clears the input field
                        guard !newTask.isEmpty else { return }
                        $todoItems.append(ToDoItem(value: ["title": newTask]))
                        newTask = ""
                    }
                }
                .padding()

                // Displays ToDoItems grouped as Active and Completed
                List {
                    Section(header: Text("Active Tasks")) {
                        ForEach(todoItems.filter { !$0.isCompleted }) { item in
                            HStack {
                                Text(item.title)
                                Spacer()
                                Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                                    .onTapGesture {
                                        if let item = item.thaw(), let realm = item.realm {
                                            try? realm.write {
                                                item.isCompleted.toggle()
                                            }
                                        }
                                    }
                            }
                        }
                        .onDelete { indexSet in
                            // Map indexSet to the filtered array to get correct objects
                            let activeItems = todoItems.filter { !$0.isCompleted }
                            let objectsToDelete = indexSet.map { activeItems[$0] }
                            for obj in objectsToDelete {
                                if let thawed = obj.thaw(), let realm = thawed.realm {
                                    try? realm.write {
                                        realm.delete(thawed)
                                    }
                                }
                            }
                        }
                    }

                    Section(header: Text("Completed Tasks")) {
                        ForEach(todoItems.filter { $0.isCompleted }) { item in
                            HStack {
                                Text(item.title)
                                    .foregroundColor(.gray)
                                Spacer()
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .onTapGesture {
                                        if let item = item.thaw(), let realm = item.realm {
                                            try? realm.write {
                                                item.isCompleted.toggle()
                                            }
                                        }
                                    }
                            }
                        }
                        .onDelete { indexSet in
                            // Map indexSet to the filtered array to get correct objects
                            let completedItems = todoItems.filter { $0.isCompleted }
                            let objectsToDelete = indexSet.map { completedItems[$0] }
                            for obj in objectsToDelete {
                                if let thawed = obj.thaw(), let realm = thawed.realm {
                                    try? realm.write {
                                        realm.delete(thawed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("My To-Do List")
        }
    }
}

#Preview {
    ContentView()
        .environment(\.realmConfiguration, Realm.Configuration(inMemoryIdentifier: "Preview"))
}
