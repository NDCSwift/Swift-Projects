

import SwiftUI

@main
struct FormExampleSwiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
