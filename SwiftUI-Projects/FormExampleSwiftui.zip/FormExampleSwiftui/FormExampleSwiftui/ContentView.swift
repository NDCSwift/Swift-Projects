//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import SwiftUI

// The main view for the FormExampleSwiftUI app
struct ContentView: View {
    // MARK: - State Properties
    
    @State private var username: String = "" // Stores the user's username input
    @State private var notificationsEnabled: Bool = false // Tracks if notifications are enabled
    @State private var volume: Double = 50.0 // Stores the volume level (0 to 100)
    @State private var selectedTheme: String = "Light" // Stores the selected theme
    
    // Available theme options
    let themes = ["Light", "Dark", "System"]
    
    // MARK: - Body
    
    var body: some View {
        ZStack {
            // Background color covering the entire screen
            Color(.systemRed)
                .edgesIgnoringSafeArea(.all)
            
            // NavigationView provides a navigation bar and enables navigation between views
            NavigationView {
                // Form organizes input fields and controls into sections
                Form {
                    // Profile Settings Section
                    Section(header: Text("Profile Settings")) {
                        // TextEditor allows multi-line text input for the username
                        TextEditor(text: $username)
                            .frame(height: 100) // Sets the height of the TextEditor
                            .textFieldStyle(PlainTextFieldStyle()) // Removes default styling
                            .font(.body) // Sets the font style
                            .padding(4) // Adds padding inside the TextEditor
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.5), lineWidth: 1) // Adds a border
                            )
                    }
                    
                    // Preferences Section
                    Section(header: Text("Preferences")) {
                        // Toggle to enable or disable notifications
                        Toggle("Enable Notifications", isOn: $notificationsEnabled)
                        
                        // Slider to adjust the volume level
                        Slider(value: $volume, in: 0...100, step: 1)
                        
                        // Label for the volume slider
                        Text("Volume")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        // Displays the current volume level
                        Text("Current Volume: \(Int(volume))")
                            .font(.body)
                            .foregroundColor(.primary)
                        
                        // Picker to select the app theme
                        Picker("Select Theme", selection: $selectedTheme) {
                            ForEach(themes, id: \.self) { theme in
                                Text(theme)
                            }
                        }
                        .pickerStyle(MenuPickerStyle()) // Displays the picker as a menu
                    }
                    
                    // Preview Section
                    Section(header: Text("Preview")) {
                        // Displays the entered username
                        HStack {
                            Text("Username:")
                                .fontWeight(.semibold)
                            Spacer()
                            Text(username.isEmpty ? "Not set" : username)
                                .foregroundColor(.secondary)
                        }
                        
                        // Displays the status of notifications
                        HStack {
                            Text("Notifications:")
                                .fontWeight(.semibold)
                            Spacer()
                            Text(notificationsEnabled ? "On" : "Off")
                                .foregroundColor(notificationsEnabled ? .green : .red)
                        }
                        
                        // Displays the current volume level
                        HStack {
                            Text("Volume:")
                                .fontWeight(.semibold)
                            Spacer()
                            Text("\(Int(volume))")
                                .foregroundColor(.primary)
                        }
                        
                        // Displays the selected theme
                        HStack {
                            Text("Theme:")
                                .fontWeight(.semibold)
                            Spacer()
                            Text(selectedTheme)
                                .foregroundColor(.primary)
                        }
                    }
                    .background(Color.clear) // Makes the background transparent
                }
                .navigationTitle("Settings") // Sets the navigation bar title
            }
        }
    }
}

// Preview provider for SwiftUI previews
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
