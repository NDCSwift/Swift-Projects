//
    // Project: FormCustomized
    //  File: Untitled.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct CoolScrollView: View {
    var body: some View {
        ZStack {
            // Custom background for the entire screen
            Color.blue.opacity(0.2).edgesIgnoringSafeArea(.all)
            
                Form {
                    Section {
                        TextField("Name", text: .constant(""))
                            .padding()
                            .background(Color.white) // Set background for TextField
                            .cornerRadius(10) // Optional: round corners for TextField
                        
                        TextField("Email", text: .constant(""))
                            .padding()
                            .background(Color.white) // Set background for TextField
                            .cornerRadius(10) // Optional: round corners for TextField
                    }
                    .listRowBackground(Color.clear) // Remove background from the section row
                    .background(Color.clear) // Remove background from the section
                    
                    Section {
                        Button("Submit") {
                            // Handle button action
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10) // Button styling
                        .frame(maxWidth: .infinity) // Center the button
                    }
                    .listRowBackground(Color.clear) // Remove background from the section row
                }
                .scrollContentBackground(.hidden) // Make the form background clear
                .background(LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.orange]),
                    startPoint: .top, endPoint: .bottom) // Apply a gradient background
                )
                
                Spacer() // Push the button and form to the top half of the screen
            
            .padding()
        }
    }
}

#Preview {
    CoolScrollView()
}
