// Project: FormCustomized
//  File: FormCustomizedApp.swift
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger


import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            // Custom background for the entire screen
            Color.blue.opacity(0.2).edgesIgnoringSafeArea(.all)
            
            VStack {
                // Form container with limited height (first half of the screen)
                Form {
                    Section ("Sign Up") {
                        TextField("Name", text: .constant(""))
                            .padding()
                            .background(Color.white) // Set background for TextField
                            .cornerRadius(10) // Optional: round corners for TextField
                        
                        TextField("Email", text: .constant(""))
                            .padding()
                            .background(Color.white) // Set background for TextField
                            .cornerRadius(10) // Optional: round corners for TextField
                    }
                    .listRowBackground(Color.clear) // Remove background from the section row
                    .background(Color.clear) // Remove background from the section
                    
                    Section {
                        Button("Submit") {
                            // Handle button action
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10) // Button styling
                        .frame(maxWidth: .infinity) // Center the button
                    }
                    .listRowBackground(Color.clear) // Remove background from the section row
                }
                .scrollContentBackground(.hidden) // Make the form background clear
                .frame(height: UIScreen.main.bounds.height / 2) // Limit form to half the screen height
                .padding(.top, 50) // Optional: add some padding from the top of the screen
                .clipShape(RoundedRectangle(cornerRadius: 20)) // Clip the form to a rounded rectangle
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.black, lineWidth: 1) // Optional: add border around the form
                )
                
                Spacer() // Push the button and form to the top half of the screen
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
