//
    // Project: AccessabilityHelper101
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    @State private var task = ["Buy Groceries", "Complete SwiftUI Tutorials", "Call Mom"]
    @State private var newTask = ""
    var body: some View {
        NavigationStack{
            VStack{
                HStack{
                    TextField("Enter new task", text: $newTask)
                        .textFieldStyle(.roundedBorder)
                        .accessibilityValue(newTask) // read what the user has typed
                    Button("Add"){
                        if !newTask.isEmpty{
                            task.append(newTask)
                            UIAccessibility.post(notification: .announcement, argument: "Task Added \(newTask)")
                            newTask = ""
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .accessibilityLabel("Add New Task") //now our voice over should announce this clearly
                }
                .padding()
                
                List{
                    ForEach(task, id:\.self) {
                        task in
                        Text(task)
                            .font(.body)
                            .accessibilityHint("Swipe Left to Delete") // inform the voice over users
                        
                    }
                    .onDelete {
                        indexSet in
                        task.remove(atOffsets: indexSet)
                    }
                }
            }
            .navigationTitle("My To-Do List")
        }
    }
}

#Preview {
    ContentView()
}
