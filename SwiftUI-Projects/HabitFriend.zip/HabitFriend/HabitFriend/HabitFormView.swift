//
    // Project: HabitFriend
    //  File: HabitFormView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import SwiftData

struct HabitFormView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss // allow us to dismiss the sheet
    
    @State private var habitName: String = ""
    @State private var habitDetails: String = ""
    var body: some View {
        NavigationView{
            Form{
                Section(header: Text("Habit Name")){
                    TextField("Enter Habit Name", text: $habitName)
                }
                
                Section(header: Text("Details (Optional)")){
                    TextEditor(text: $habitDetails)
                        .frame(height: 100)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                }
                
                Section{
                    Button("Save Habit"){
                        saveHabit()
                    }
                    .disabled(habitName.isEmpty)
                }
                
            }
            .navigationTitle("New Habit")
            .toolbar{
                ToolbarItem(placement: .cancellationAction){
                    Button("Cancel"){ dismiss() }
                }
            }
        }
    }
    
    private func saveHabit(){
        let newHabit = Habit(title: habitName, details: habitDetails.isEmpty ? nil : habitDetails)
        modelContext.insert(newHabit)// add that habit to swift data
        dismiss()
    }
}

#Preview {
    HabitFormView()
}
