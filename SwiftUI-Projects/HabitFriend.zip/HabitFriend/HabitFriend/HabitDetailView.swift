//
    // Project: HabitFriend
    //  File: HabitDetailView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import SwiftData

struct HabitDetailView: View {
    @Bindable var habit: Habit
    var body: some View {
        VStack{
            Text(habit.title)
                .font(.largeTitle)
                .bold()
            
            if let details = habit.details{
                Text(details)
                    .font(.subheadline)
                    .foregroundStyle(.gray)
            }
            //scrollable view for the calendar
            
            ScrollView(.horizontal){
                LazyHGrid(rows: [GridItem(.fixed(50))]){
                    ForEach(0..<30){ day in
                        let date = Calendar.current.date(byAdding: .day, value: -day, to: Date())!
                        Button(action: { toggleCompletion(for: date)}){
                            Circle()
                                .fill(habit.progress.contains(date) ? Color.green : Color.gray.opacity(0.3))
                                .overlay(Text("\(day + 1)"))
                                .foregroundStyle(.white)
                                .font(.caption)
                        }
                    }
                }
            }
            
            
            
        }
    }
    private func toggleCompletion(for date: Date){
        if let index = habit.progress.firstIndex(of: date){
            habit.progress.remove(at: index) // remove if already marked
        } else{
            habit.progress.append(date)//add if not marked
        }
    }
    
    
}


