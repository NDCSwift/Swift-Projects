//
    // Project: HabitFriend
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import SwiftData

struct HabitsListView: View {
    @Environment(\.modelContext) private var modelContext // swift data context
    @Query private var habits: [Habit] // fetches habits from swift data
    @State private var showingAddHabit = false
    
    var body: some View {
        NavigationView{
            List{
                ForEach(habits){ habit in
                    NavigationLink(destination: HabitDetailView(habit: habit)){
                        VStack(alignment: .leading){
                            Text(habit.title)
                                .font(.headline)
                            if let details = habit.details {
                                Text(details)
                                    .font(.caption)
                                    .foregroundStyle(Color.gray)
                            }
                        }
                    }
                }
                .onDelete(perform: deleteHabit) // allow us to swipe to delete habits
            }
            .navigationTitle("My Habits")
            .toolbar {
                Button(action: { showingAddHabit = true}){
                    Label("Add Habit", systemImage: "plus.circle.fill")
                }
            }
            .sheet(isPresented: $showingAddHabit){
                HabitFormView()
            }
        }
    }
    
    private func deleteHabit(at offsets: IndexSet){
        for index in offsets {
            modelContext.delete(habits[index])
        }
    }
}

#Preview {
    HabitsListView()
}
