//
    // Project: List_ForEach
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct Task: Identifiable{
    let id = UUID()
    let title: String
}


struct ContentView: View {
    @State private var tasks = [Task(title: "Buy groceries"), Task(title: "Read a book"), Task(title: "Workout")]
    var body: some View {

        List {
                   ForEach(tasks) { task in
                       Text(task.title)
                   }
                   .onDelete { indexSet in
                       tasks.remove(atOffsets: indexSet) // swipe-to-delete
                   }
                   .onMove { indices, newOffset in
                       tasks.move(fromOffsets: indices, toOffset: newOffset) // drag-to-reorder
                   }
                   .swipeActions(edge: .trailing) { // custom swipe buttons (iOS 15+)
                       Button(role: .destructive) {
                           // delete action
                       } label: {
                           Label("Delete", systemImage: "trash")
                       }
                   }
               }
               .toolbar {
                   EditButton() // enables drag-to-reorder
               }

    }
}

#Preview {
    ContentView()
}
