//
//  LocalizedDemoApp.swift
//  LocalizedDemo
//
//  Created by Noah Carpenter on 2024-12-04.
//

import SwiftUI

@main
struct LocalizedDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
