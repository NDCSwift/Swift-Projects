//
    // Project: Local&Remote_Images
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    let imageURL = URL(string: "https://images.squarespace-cdn.com/content/v1/5dd8630d09ab5908e35b35a0/1574463308006-PDSJDF9EEEB0TJG7TL1N/img-HotDogStock-1080x675.png?format=2500w")
    let invalidImage = URL(string: "example.example/NOPE")
    var body: some View {
        VStack {

  
            AsyncImage(url: imageURL, transaction: Transaction(animation: .easeIn)) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                case .success(let image):
                    image
                        .resizable()
                        .frame(height: 300)
                        .accessibilityLabel("Picture of a hotdog with no condiments")
                case .failure(let error):
                    Text("No internet Connection")
                    // print("error loading image: \(error.localizedDescription)")
                
                @unknown default:
                    EmptyView()
                }
                
            }
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
