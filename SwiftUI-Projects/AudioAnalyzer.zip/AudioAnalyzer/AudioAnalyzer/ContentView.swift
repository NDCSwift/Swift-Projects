//
    // Project: AudioAnalyzer
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    @StateObject private var audioAnalyzer = AudioAnalyzer()
    var body: some View {
        VStack {
        Text("Real Time Audio Analysis")
                .font(.title)
                .padding()
                Spacer()
            
            HStack(spacing: 15){
                VStack{
                    Text("Bass")
                        .font(.caption)
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: 30, height: CGFloat(audioAnalyzer.bassLevel * 300)+10)
                        .animation(.easeOut(duration: 0.05), value: audioAnalyzer.bassLevel)
                }
                VStack{
                    Text("mid")
                        .font(.caption)
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: 30, height: CGFloat(audioAnalyzer.midLevel * 300)+10)
                        .animation(.easeOut(duration: 0.05), value: audioAnalyzer.midLevel)
                }
                VStack{
                    Text("Treble")
                        .font(.caption)
                    Rectangle()
                        .fill(Color.purple)
                        .frame(width: 30, height: CGFloat(audioAnalyzer.trebleLevel * 300)+10)
                        .animation(.easeOut(duration: 0.05), value: audioAnalyzer.trebleLevel)
                }
            }
            .padding()
            Spacer()
            Button("Start Listening"){
                audioAnalyzer.startAnalyzing()
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
