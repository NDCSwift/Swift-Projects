//
    // Project: AudioAnalyzer
    //  File: AuidoAnalyzer.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
// Handle real-time Audio frequence analysis

import AVFoundation
import Accelerate

class AudioAnalyzer: ObservableObject {
    private var audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode?
    private var bufferSize: AVAudioFrameCount = 1024
    
    @Published var bassLevel: Float = 0.0 //Low freqeuncies (Bass)
    @Published var midLevel: Float = 0.0 // mid level
    @Published var trebleLevel: Float = 0.0 // high freq
    
    /// Start capturing Live Audio and analyzing those freqs
    
    func startAnalyzing() {
        // check for microphone permissions
        AVAudioApplication.requestRecordPermission {
            granted in
            DispatchQueue.main.async {
                if granted{
                    self.setupAudioEngine()
                } else{
                    print("Microphone not enabled")
                }
            }
        }
        
    }
    
    private func setupAudioEngine() {
        do{
            inputNode = audioEngine.inputNode
            let format = inputNode?.outputFormat(forBus: 0)
            
            inputNode?.removeTap(onBus: 0)
            inputNode?.installTap(onBus: 0, bufferSize: bufferSize, format: format){
                buffer, _ in
                self.performFFT(buffer: buffer)
            }
            try audioEngine.start()
        } catch{
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }
    func stopAnalyzing(){
        audioEngine.stop()
        inputNode?.removeTap(onBus: 0)
    }
    private func performFFT(buffer: AVAudioPCMBuffer){
        guard let channelData = buffer.floatChannelData?[0] else{return}
        let frameLength = vDSP_Length(buffer.frameLength)
        
        var magnitudes = [Float](repeating: 0.0, count: Int(frameLength))
        vDSP_vabs(channelData, 1, &magnitudes, 1, frameLength)
        
        let bassRange = 0..<10
        let midRange = 10..<40
        let trebleRange = 40..<100
        
        let bassPower = bassRange.reduce(0.0){ $0 + magnitudes[$1]} / Float(bassRange.count)
        let midPower = midRange.reduce(0.0){ $0 + magnitudes[$1]} / Float(midRange.count)
        let treblePower = trebleRange.reduce(0.0){ $0 + magnitudes[$1]} / Float(trebleRange.count)
        
        DispatchQueue.main.async {
            self.bassLevel = bassPower
            self.midLevel = midPower
            self.trebleLevel = treblePower
        }
        
    }
}
