//
// Project: MacOSNotesApp
//  File: NoteDetailView.swift
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
    

import SwiftUI
import UniformTypeIdentifiers

// View representing the detail/edit screen for a single note
struct NoteDetailView: View {
    // Binding to a note object so changes here reflect in the source
    @Binding var note: Note
    // State variable to toggle between edit and markdown preview mode
    @State private var previewMode = false
    
    var body: some View {
        // Main vertical stack aligning content to the leading edge
        VStack(alignment: .leading){
            
            // Text field for editing the note's title
            TextField("Title", text: $note.title)
                .font(.title) // Displayed in large title font
                .padding(.bottom) // Space below the title
            
            // Toggle to switch between markdown preview and edit mode
            Toggle("Markdown Preview", isOn: $previewMode)
                .toggleStyle(.checkbox) // Use a checkbox style for toggle

            // Conditional view: show either markdown preview or text editor
            if previewMode {
                // Markdown preview mode: render the note's body as formatted text
                ScrollView {
                    Text(.init(note.body)) // Interpret body as Markdown
                        .padding()
                        .textSelection(.enabled) // Allow user to select/copy text
                }
            } else {
                // Edit mode: allow user to edit the note's body
                TextEditor(text: $note.body)
                    .font(.body)
                    .border(Color.gray.opacity(0.3)) // Light border for visual clarity
            }
            
        }
        // Toolbar with Save and Export buttons
        .toolbar {
            // Save button: updates and persists the note
            Button("Save") {
                NoteStore().update(note: note)
                NoteStore().save()
            }
            // Export button: calls exportNote() to save note to a file
            Button("Export") {
                exportNote()
            }
        }
        .padding() // Padding around the whole view
        .navigationTitle(note.title) // Show the note title in the navigation bar
    }

    // Function to export the note's body as a plain text file
    func exportNote() {
        // Create a save panel for user to choose the file location
        let panel = NSSavePanel()
        panel.allowedContentTypes = [UTType.plainText] // Restrict to plain text files
        panel.nameFieldStringValue = note.title + ".txt" // Default file name
        // Show the panel and write the note body if user confirms
        if panel.runModal() == .OK, let url = panel.url {
            do {
                try note.body.write(to: url, atomically: true, encoding: .utf8)
                note.exportURL = url // Optionally store the export URL
            } catch {
                print("❌ Failed to export note: \(error)")
            }
        }
    }

}


#Preview {
    // SwiftUI preview for NoteDetailView with a sample note
    @State var sampleNote = Note(title: "preview", body: "Preview body")
    NoteDetailView(note: $sampleNote)
}
