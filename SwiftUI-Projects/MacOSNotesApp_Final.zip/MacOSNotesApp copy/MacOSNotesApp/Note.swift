//
    // Project: MacOSNotesApp
    //  File: Note.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import Foundation

// Represents a single note with a title, body, and optional export file location
struct Note: Identifiable, Codable, Hashable {
    // Unique identifier for the note
    let id: UUID

    // The title of the note
    var title: String

    // The main content of the note
    var body: String

    // Optional file URL where the note was exported to
    var exportURL: URL?

    // Initializes a new note with optional ID and export URL
    init(id: UUID = UUID(), title: String, body: String, exportURL: URL? = nil) {
        self.id = id
        self.title = title
        self.body = body
        self.exportURL = exportURL
    }
}
