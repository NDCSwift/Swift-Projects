//
// Project: MacOSNotesApp
//  File: NoteStore.swift
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import Foundation
import Combine

// Stores and manages a list of notes with loading, saving, and exporting support
@MainActor
class NoteStore: ObservableObject {
    // Publishes changes to the notes array so the UI updates automatically
    @Published var notes: [Note] = []

    // Holds Combine subscriptions to keep the sink alive
    private var cancellables = Set<AnyCancellable>()

    // The file URL where notes are saved and loaded from (documents directory + "notes.json")
    private let saveURL: URL = {
        // Get the user's document directory URL
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        // Append the filename "notes.json" to the documents directory URL
        return docs.appendingPathComponent("notes.json")
    }()

    // Initializes the NoteStore by loading saved notes and setting up automatic saving on changes
    init() {
        // Load existing notes from disk
        load()
        // Observe changes to the notes array and save automatically whenever it changes
        $notes
            .sink { [weak self] _ in self?.save() }
            .store(in: &cancellables)
    }

    // Loads notes from the saveURL file, or creates a default welcome note if loading fails
    func load() {
        do {
            // Attempt to read data from the saveURL file
            let data = try Data(contentsOf: saveURL)
            // Decode the JSON data into an array of Note objects
            notes = try JSONDecoder().decode([Note].self, from: data)
        } catch {
            // If loading or decoding fails, initialize with a default welcome note
            notes = [Note(title: "Welcome", body: "Start writing notes here!")]
        }
    }

    // Saves the current notes array to disk as pretty-printed JSON at the saveURL location
    func save() {
        do {
            // Create a JSON encoder and set output formatting to pretty printed
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            // Encode the notes array into JSON data
            let data = try encoder.encode(notes)
            // Write the JSON data to the saveURL file atomically
            try data.write(to: saveURL, options: .atomic)
        } catch {
            // Print an error message if saving fails
            print("❌ Failed to save notes: \(error)")
        }
    }

    // Updates an existing note in the notes array and exports its body to a file if exportURL is set
    func update(note: Note) {
        // Find the index of the note with the matching id
        if let index = notes.firstIndex(where: { $0.id == note.id }) {
            // Replace the note at the found index with the updated note
            notes[index] = note

            // If the note has an exportURL, write its body text to that file
            if let url = note.exportURL {
                do {
                    // Write the note's body string to the specified URL using UTF-8 encoding
                    try note.body.write(to: url, atomically: true, encoding: .utf8)
                } catch {
                    // Print an error message if exporting the note fails
                    print("❌ Failed to export note to file: \(error)")
                }
            }
        }
    }
}
