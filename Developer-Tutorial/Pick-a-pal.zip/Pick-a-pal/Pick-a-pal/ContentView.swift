//
//  ContentView.swift
//  Pick-a-pal
//
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI

struct ContentView: View {
    // Array to store names entered by the user
    @State private var names: [String] = []
    
    // Holds the name currently being typed in the text field
    @State private var nameToAdd = ""
    
    // Stores the randomly picked name
    @State private var pickedName = ""
    
    // Determines whether the picked name should be removed from the list
    @State private var shouldRemovePickedName = false
    
    var body: some View {
        VStack {
            VStack(spacing: 8){
                // Display an icon and title for the app
                Image(systemName: "person.3.sequence.fill")
                    .foregroundStyle(.tint)
                    .symbolRenderingMode(.hierarchical)
                
                Text("Pick-A-Pal")
            }
            .font(.title)
            .bold()
            
            // Displays the picked name if one has been chosen
            Text(pickedName.isEmpty ? " " : pickedName)
                .font(.title2)
                .bold()
                .foregroundStyle(.tint)

            // List of names added by the user
            List{
                ForEach(names, id:\.description){ name in
                    Text(name)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))
            
            // Text field for adding new names
            TextField("Add Name", text: $nameToAdd)
                .autocorrectionDisabled()
                .onSubmit {
                    if !nameToAdd.isEmpty{
                        names.append(nameToAdd)
                        nameToAdd = "" // Clear text field after adding name
                    }
                }
            
            Divider() // Visual separator
            
            // Toggle to decide if the picked name should be removed from the list
            Toggle("Remove when Picked", isOn: $shouldRemovePickedName)
            
            // Button to pick a random name from the list
            Button {
                if let randomName = names.randomElement(){
                    pickedName = randomName
                    
                    if shouldRemovePickedName{
                        // Remove the picked name from the list if the toggle is on
                        names.removeAll { name in
                            return (name == randomName)
                        }
                    }
                } else {
                    pickedName = "" // Reset if there are no names
                }
            } label: {
                Text("Pick Random Name")
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
            }
            .buttonStyle(.borderedProminent)
            .font(.title2)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
