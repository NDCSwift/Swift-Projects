//
//  Pick_a_palApp.swift
//  Pick-a-pal
//
//  Created by Noah Carpenter on 2025-01-02.
//

import SwiftUI

@main
struct Pick_a_palApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
