//
    // Project: IAPDemo
    //  File: IAPDemoApp.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import RevenueCat

@main
struct IAPDemoApp: App {
    init() {
        Purchases.configure(withAPIKey: "YOUR_REVENUECAT_API_KEY")
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
