//
    // Project: IAPDemo
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI
import RevenueCat

struct ContentView: View {
    // Tracks the customer information returned from RevenueCat
    @State private var customerInfo: CustomerInfo?
    // Tracks subscription status (true if user has active entitlement)
    @State private var isPro: Bool = false
    // Tracks number of coins purchased by the user
    @State private var coinCount: Int = 0
    var body: some View {
        
        // Display the current number of coins
        Text("Coins: \(coinCount)")
        // Button to initiate coin purchase
        Button("Buy Coins"){
            purchase(productID: "YOURPRODUCTID")
        }
        // Button to initiate monthly subscription purchase
        Button("Subscribe Monthly"){
            purchase(productID: "YOURPRODUCTID")
        }
        // Displays user's subscription status with color indication
        Text(isPro ? "Pro user!" : "Free user")
            .foregroundStyle(isPro ? .green : .red)
        // Button to check subscription status and update UI accordingly
        Button("Check Sub Status"){
            checkSubStatus()
        }
        
    }
    // Handles the purchase flow for a given product ID
    func purchase(productID: String){
        Task{
            do{
                // Fetch product info from RevenueCat for the given product ID
                let products: [StoreProduct] = await Purchases.shared.products([productID])
                guard let product = products.first else{
                    print("Product not found \(productID)")
                    return
                }
                // Initiate purchase for the fetched product
                let result = try await Purchases.shared.purchase(product: product)
                // Update local customer info with purchase result
                customerInfo = result.customerInfo
                // Update subscription status based on active entitlements
                isPro = customerInfo?.entitlements.active.contains(where: {
                    $0.value.isActive
                }) ?? false
                
                // If the purchased product corresponds to coins, increment coin count
                if productID == "MATCHING PRODUCT ID" {
                    coinCount += 10
                }
                
            } catch {
                print("Failed to purchase \(error)")
            }
        }
        
    }
    
    // Checks the current subscription status and updates the UI accordingly
    func checkSubStatus(){
        Task{
            do{
                // Fetch latest customer info from RevenueCat
                let info = try await Purchases.shared.customerInfo()
                // Update subscription status based on active entitlements
                isPro = info.entitlements.active.contains(where: {
                    $0.value.isActive
                })
            } catch{
                print("Failed to fetch customer info \(error)")
            }
        }
    }
}

#Preview {
    ContentView()
}
