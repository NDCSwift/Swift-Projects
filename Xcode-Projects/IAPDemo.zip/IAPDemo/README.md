# SwiftUI RevenueCat In-App Purchase Demo

This demo project showcases how to implement **In-App Purchases (IAP)** in a SwiftUI app using **RevenueCat** and **StoreKit**, including local testing and sandbox support.

## 🧪 Features

- ✅ Buy consumables (e.g. 10 Coins)
- ✅ Subscribe to a monthly plan
- ✅ Track entitlements in RevenueCat
- ✅ Local `.storekit` config for simulator testing
- ✅ Basic UI for testing purchases
- ✅ Coin counter updates after consumable purchase

---

## 🚀 Getting Started

### 1. Clone the Project  
Open `IAPDemo.xcodeproj` in Xcode 15+.

### 2. Configure StoreKit Testing  
- A `.storekit` config file is included with 2 products:
  - `coins_pack.ndcSample` – consumable
  - `pro_monthly.ndcSample` – auto-renewing subscription
- Ensure this file is selected under **Scheme > Run > Options > StoreKit Configuration**.

### 3. Set Up RevenueCat
- Create a [RevenueCat](https://www.revenuecat.com/) project
- Add **matching product IDs** to your default offering
- Replace `YOUR_PUBLIC_REVENUECAT_API_KEY` in `IAPDemoApp.swift` with your real key (`appl_...` format)

---

## 🧾 Product Behavior

### Consumable: `coins_pack.ndcSample`
- Adds +10 coins to `coinCount` each time it is purchased

### Subscription: `pro_monthly.ndcSample`
- Unlocks "Pro User" status via active entitlement

## 📣 Credits

Created by [@NoahDoesCoding97](https://www.youtube.com/@NoahDoesCoding97)  
Follow for iOS, SwiftUI, and app monetization tutorials!
