//
// Project: XcodeDebugging101
//  File: ContentView.swift
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import SwiftUI

struct ContentView: View {
    // MARK: - State Properties
    @State private var counter: Int = 0
    @State private var items: [String]? = ["Apple", "Banana", "Cherry"]
    
    var body: some View {
        VStack(spacing: 20) {
            // Counter Section
            Text("Counter: \(counter)")
                .font(.headline)
            
            Button("Increment Counter") {
                incrementCounter()
            }
            
            Divider()
            
            // Calculation Section
            Text("Sum of 2 + 3: \(calculateSum(a: 2, b: 3))")
                .font(.headline)
            
            Divider()
            
            // List Section
            Text("Fruits List")
                .font(.headline)
            List {
                ForEach(items ?? [], id: \.self) { item in
                    Text(item)
                }
            }
            .frame(height: 150)
            
            Divider()
            
            // Crash Demo Section
            Button("SHOULDN'T Crash App") {
                crashApp()
            }
        }
        .padding()
    }
    
    // MARK: - Action Methods
    
    // Somethings not quite right here!
    func incrementCounter() {
        counter += 2
    }
    
    /// Demonstrates stepping into this function from `calculateSum`.
    func multiply(a: Int, b: Int) -> Int {
        return a * b
    }
    
    // This doesn't work quite well either
    func calculateSum(a: Int, b: Int) -> Int {
        let sum = a * b
        let product = multiply(a: a, b: b)
        print("Product is \(product)")
        return sum
    }
    
    ///Crashes our app until fixed
    func crashApp() {
        // This will crash because index 3 is out of bounds for the `items` array.
        let item = items![3]
        print("Crashed item: \(item)")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
