
# Xcode Debugging for Beginners: Master Swift Debugging Tools

## 🚀 Project Overview

This simple SwiftUI application serves as a playground to demonstrate common debugging scenarios, including:
* Logical errors that produce unexpected output.
* Runtime errors (crashes) due to invalid operations.
* The difference between inspecting variables at different points in execution.
* Visual UI hierarchy inspection.

The project is intentionally built with a few "bugs" and areas designed for you to practice using Xcode's debugger, following along with the video tutorial.

## 📦 How to Use This Project

To get started with this debugging demo:

### Prerequisites
* Xcode (latest stable version recommended)
* macOS

1.  **Open in Xcode:**
    Navigate to the cloned directory and open the `.xcodeproj` 
    
2.  **Run the App:**
    Select a simulator (e.g., "iPhone 15 Pro") or a connected device and click the `Run` button in Xcode.

## Debugging Scenarios (Follow Along with the Video!)

This project contains several areas specifically designed for you to practice debugging. The video tutorial will guide you through how to use Xcode's tools to diagnose and fix these issues.

### 1. The Mysterious Counter
* **Location:** Look for the `incrementCounter()` function in `ContentView.swift`.
* **Problem:** When you tap the "Increment Counter" button, the number updates in an unexpected way.
* **Debugging Focus:** Use **Breakpoints** to pause execution and the **Variables View** to inspect `counter`'s value *before* and *after* the line of code executes.

### 2. The Faulty Sum Calculation
* **Location:** Investigate the `calculateSum(a:b:)` function in `ContentView.swift`.
* **Problem:** The sum of 2 + 3 is not what you'd expect on the screen.
* **Debugging Focus:** Set a **Breakpoint** inside `calculateSum`. Use **Stepping Controls** (`Step Over`, `Step Into`) to follow the execution path. Pay close attention to the `product` variable's value and how it's being used. Also, try using the `po` command in the **Console** to inspect variables.

### 3. The Unwanted Crash!
* **Location:** The `crashApp()` function in `ContentView.swift`.
* **Problem:** Tapping the "SHOULDN'T 'Crash App" button will cause the application to terminate unexpectedly.
* **Debugging Focus:** Let the app crash! Xcode will automatically pause at the crash site. Examine the **Call Stack** in the Debug Navigator to understand the sequence of events leading to the crash. Inspect the `items` array in the **Variables View** to understand why the crash occurred.

### 4. UI Layout Inspection
* **Problem:** (No deliberate bug here, but an opportunity to learn!) Imagine you have UI elements that aren't aligning correctly or are hidden.
* **Debugging Focus:** Use Xcode's powerful **View Debugger** (the overlapping squares icon in the debug bar when your app is running). Explore the 3D hierarchy, select different views, and inspect their frames and modifiers.

---

## 🤝 Contribution & Feedback

This project is primarily for educational purposes. However, if you find any issues with the demo code itself or have suggestions for improvements, feel free to let me know https://www.youtube.com/@NoahDoesCoding97

