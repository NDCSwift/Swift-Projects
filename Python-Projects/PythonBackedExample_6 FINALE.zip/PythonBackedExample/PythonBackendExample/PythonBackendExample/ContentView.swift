//
    // Project: PythonBackendExample
    //  File: ContentView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ProductViewModel()
    var body: some View {
        NavigationView{
            Group{
                if viewModel.isLoading{
                    ProgressView("Loading...")
                } else if let error = viewModel.errorMessage{
                    Text("Error: \(error)")
                        .foregroundStyle(Color.red)
                        .multilineTextAlignment(.center)
                        .padding()
                } else {
                    List(viewModel.products){ product in
                        HStack{
                            Text(product.name)
                            Spacer()
                            Text(String(format: "%.2f", product.price))
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Products")
            .onAppear {
                viewModel.fetchProducts()
            }
        }
    }
}

#Preview {
    ContentView()
}
