//
    // Project: PythonBackendExample
    //  File: RegisterViewModel.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
import Foundation

class RegisterViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""
    @Published var message: String?
    @Published var isLoading = false
    
    
    private let baseURL = "https://pythonbackedexamplendcyt.onrender.com"
    
    func registerUser(){
        guard let url = URL(string: "\(baseURL)/register") else {
            message = "Invalid URL"
            return
        }
        
        let body: [String: String] = [
            "username": username,
            "password": password,
        ]
        
        guard let jsonData = try? JSONSerialization.data(withJSONObject: body) else {
            message = "Failed to encode request body"
            return
        }
        
        var request = URLRequest(url:url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        isLoading = true
        message = nil
        
        URLSession.shared.dataTask(with: request) { data, response, error in
        
            DispatchQueue.main.async{
                self.isLoading = false
                
                if let error = error {
                    self.message = "Error \(error.localizedDescription)"
                    return
                }
                guard let data = data else{
                    self.message = "No data returned"
                    return
                }
                if let responseDict = try? JSONSerialization.jsonObject(with: data) as? [String: String]{
                    self.message = responseDict["message"] ?? responseDict["error"] ?? "Unknown response"
                } else {
                    self.message = "Invlaid response Format"
                }
            }
        }.resume()
        
    }
}
