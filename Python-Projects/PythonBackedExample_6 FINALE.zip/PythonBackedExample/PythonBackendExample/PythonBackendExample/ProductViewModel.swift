//
    // Project: PythonBackendExample
    //  File: ProductViewModel.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import Foundation

class ProductViewModel: ObservableObject {
    @Published var products: [Product] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let baseURL = "https://pythonbackedexamplendcyt.onrender.com"
    
    func fetchProducts() {
        isLoading = true
        errorMessage = nil
        
        guard let url = URL(string:"\(baseURL)/products") else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, respose, error in
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                if let error = error {
                    self.errorMessage = error.localizedDescription
                    return
                }
                guard let data = data else{
                    self.errorMessage = "No data returned"
                    return
                }
                do{
                    self.products = try JSONDecoder().decode([Product].self, from: data)
                } catch {
                    self.errorMessage = "Failed to decode \(error.localizedDescription)"
                }
                
            }
            
        }.resume()
    }
}
