//
    // Project: PythonBackendExample
    //  File: RegisterView.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import SwiftUI

struct RegisterView: View {
    @StateObject private var  viewModel = RegisterViewModel()
    var body: some View {
        NavigationView{
            Form {
                Section(header: Text("Create Account")){
                    TextField("Username", text: $viewModel.username)
                        .autocorrectionDisabled()
                        .autocapitalization(.none)
                    SecureField("Password", text: $viewModel.password)
                    
                    Section{
                        Button(action: {
                            viewModel.registerUser()
                        }){
                            if viewModel.isLoading{
                                ProgressView("Loading..")
                            } else{
                                Text("register")
                            }
                        }
                        .disabled(viewModel.username.isEmpty || viewModel.password.isEmpty)
                    }
                    if let message = viewModel.message {
                        Section{
                            Text(message)
                        }
                    }
        
                }
            }
            .navigationTitle("Register")
        }
        
    }
}

#Preview {
    RegisterView()
}
