# Python Backend API

- User Authentication
- SQLite database
- Free Deployment on Render
- Products adding and viewing

## Whats inside

## How to run locally and git clone