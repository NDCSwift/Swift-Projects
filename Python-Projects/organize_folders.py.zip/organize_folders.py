import os
import shutil 
import time

def move_file(directory, filename, folder):
    source = os.path.join(directory, filename)

    destination_folder = os.path.join(directory, folder)

    if not os.path.exists(destination_folder):
        os.makedirs(destination_folder)
        print(f"Created folder {folder}")

    destination = os.path.join(destination_folder, filename)

    if os.path.exists(destination):
        print(f"{filename} already exists in the  {folder}, skipping this item")
    else:
        shutil.move(source, destination_folder)
        print(f"moved {filename} to the {folder} folder")

def organize_folder(directory):
    organize_rules = {
        "Music": [".mp3", ".wav"],
        "Pictures": [".png", ".jpg"],
        "Documents": [".pdf", ".txt"],
    }

    for filename in os.listdir(directory):
        source = os.path.join(directory, filename)

        if os.path.isdir(source):
            continue
        
        file_moved = False

        for folder, extensions in organize_rules.items():
            if any(filename.lower().endswith(ext) for ext in extensions):
                move_file(directory, filename, folder)
                file_moved = True
                break

        if not file_moved:
            move_file(directory, filename, "Other")

def auto_organize(directory, delay):
    print(f"Monitorting {directory} every {delay} seconds")
    while True:
        organize_folder(directory)
        time.sleep(delay)

downloads_folder = input("Enter the path of your downloads folder:")

delay_seconds = int(input("Enter how often in seconds to ogranize the folder"))

start = input("ready to start auto organizing your downloads: yes / no").lower()

if start == "yes":
    auto_organize(downloads_folder, delay_seconds)
else:
    print("Operation is cancelled")