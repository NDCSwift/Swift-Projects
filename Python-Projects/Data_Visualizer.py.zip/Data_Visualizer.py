import pandas as pd
import matplotlib.pyplot as plt 

data = {
    'Fruits': ['Apples', 'Bananas', 'Oranges', 'Grapes'],
    'Quantity': [10, 15, 7, 5]
}

df = pd.DataFrame(data)

print(df)

df.plot.bar(x='Fruits', y='Quantity', color= 'skyblue', legend =False)
plt.title('Fruit Quantities')
plt.xlabel('Fruit')
plt.ylabel('Quantity')
plt.show()

plt.pie(df['Quantity'], labels=df ['Fruits'], autopct='%1.1f%%')
plt.title('Fruits in a pie chart')
plt.axis('equal')
plt.show()

temp_data = {
    'Days': ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], 
    'Temperature': [22,19,15,20,31]
}

temp_df = pd.DataFrame(temp_data)

plt.plot(temp_df['Days'], temp_df['Temperature'], marker= 'o', linestyle = '-', color ="purple")
plt.title('Weekly Temps!')
plt.xlabel('Days')
plt.ylabel('Temperature in Celcius')
plt.grid(False)
plt.show()