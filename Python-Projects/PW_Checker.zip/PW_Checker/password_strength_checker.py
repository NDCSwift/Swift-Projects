import re 

def check_pw_str(password):
  score = 0
  suggestions = []

  #1 length
  if len(password) >= 8:
    score += 1
  else:
    suggestions.append("At least 8 characters long")

  #2 Uppercase letters
  if re.search(r"[A-Z]", password):
    score += 1
  else:
    suggestions.append("Include uppercase letters (A-Z)")

  #3 Lowercase letters
  if re.search(r"[a-z]", password):
      score += 1
  else:
    suggestions.append("Include uppercase letters (a-z)")

  #4 Numbers
  if re.search(r"[0-9]", password):
    score += 1
  else:
    suggestions.append("Include at least one number (0-9)")

  #5 Special characters
  if re.search(r"[!@#$%^&*()_\-\,\.\?\/\\\{\}\<\>]", password):
    score += 1
  else:
    suggestions.append("include special characters (!@#@$%...)")
  
  if score == 5:
    strength = "Very Strong"
    color = "green"
  elif score >= 3:
    strength = "Medium"
    color = "orange"
  else: 
    strength = "Weak"
    color = "red"

  return strength, color, suggestions