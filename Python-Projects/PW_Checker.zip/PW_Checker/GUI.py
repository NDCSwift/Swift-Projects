import tkinter as tk
from tkinter import ttk
from password_strength_checker import check_pw_str

def main():
  root = tk.Tk()
  root.title("Password Strength Checker")
  root.geometry("400x300")
  root.resizable(False,False)

  #Password labels
  password_label = ttk.Label(root, text="Enter Password")
  password_label.pack(pady=10)

  #Password Input
  password_entry = ttk.Entry(root, width= 50, show="*")
  password_entry.pack(pady=5)

  #Password feedback
  suggestion_label = ttk.Label(root, text="Strength: ", font=('Arial', 10))
  suggestion_label.pack(pady=5)

  #Event handler triggered on key release in pw textbox
  def on_pw_change(event=None):
    password = password_entry.get()
    strength, color, suggestions = check_pw_str(password)

    suggestion_label.config(text=f"Strength: {strength}", foreground=color)

    if suggestions:
      suggestion_label.config(text="Suggestions:\n" + "\n".join(suggestions), foreground=color)
    else:
      suggestion_label.config(text="No suggestions", foreground="green")
  
  password_entry.bind("<KeyRelease>", on_pw_change)

  root.mainloop()

if __name__ == "__main__":
    main()
  

    
