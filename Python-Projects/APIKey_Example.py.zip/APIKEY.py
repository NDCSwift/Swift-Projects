# Import built-in and third-party libraries
import os  # Used to access environment variables (like our API key)
import requests  # Used to make the actual HTTP request to the weather API
from dotenv import load_dotenv  # Loads variables from a .env file into the environment

# Load your API key from the .env file
load_dotenv()  # This makes sure .env variables are available to the script
api_key = os.getenv("OPENWEATHER_API_KEY")  # Grab the actual API key safely

# Choose the city you want to look up
city = "Toronto"  # You can change this to any city you like

# Create the request URL using the API key and city
url = (
    f"https://api.openweathermap.org/data/2.5/weather"
    f"?q={city}&appid={api_key}&units=metric"
)
# The units=metric part gives us temperature in Celsius

# Make the request to the weather API
response = requests.get(url)  # Send the GET request
data = response.json()  # Parse the response into JSON format

# Display the weather info, or handle errors if something goes wrong
if response.status_code == 200:
    # If the request was successful, print the weather description and temp
    print(f"🌤️ Weather in {city}: {data['weather'][0]['description'].title()}")
    print(f"🌡️ Temperature: {data['main']['temp']}°C")
else:
    # If there was an error, show the message from the API
    print("Error fetching weather data:", data.get("message"))