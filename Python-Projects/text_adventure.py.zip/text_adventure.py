def intro():
    print("You findyourself in a dark forest. Two paths lie ahead.")
    print("Do you go left or right?")

    choice = input("Type 'left' or 'right'").lower()

    if choice == "left":
        left_path()
    elif choice == "right":
        right_path()
    else:
        print("invalid choice, please type 'left' or 'right'")
        intro()
        

def left_path():
    print("You meet a friendly wizard. He gives you a powerful sword")
    print("Do you want to explore the castle or return home?")

    choice = input("Type 'castle' or 'home'").lower()

    if choice == "castle":
        explore_castle()
    elif choice == "home":
        print("you safely returned home with your new sword")
        play_again()
    else:
        print("Invalid choice please select 'castle' or 'home'")
        left_path()

def right_path():
    print("You encounter a dragon. They capture you!")
    print("You must clean the dragons lair or try to escape")

    choice = input("Type 'clean' or 'escape'").lower()

    if choice == "clean":
        print("You chose to clean the dragons lair for the next month as payment for freedom")
        play_again()

    elif choice == "escape":
        print("Avoided the dragon! and managed to escape their lair")
        escape_dragon()
    else:
        print("invalid, please type 'clean' or 'escape'")
        right_path()

def explore_castle():
    print("Inside the castle you find glorious loot!")
    play_again()

def escape_dragon():
        print("you safely return home with a new story to share")
        play_again()

def play_again():
    choice = input ("Do you want to play again? (yes/no)").lower()

    if choice == "yes":
        intro()
    elif choice == "no":
        print("thanks for playing! Goodbye!")
    else:
        print("please type 'yes' or 'no'")
        play_again()

intro()