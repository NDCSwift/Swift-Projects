import requests
from bs4 import BeautifulSoup

url = 'https://www.python.org'

response = requests.get(url)

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')

    headings =soup.find_all('h2')
    print("headings on this page:")
    for heading in headings:
        print(heading.text)

    links = soup.find_all('a')
    print("\nLinks on this page:")
    for link in links:
        href = link.get('href')
        if href:
            print(href)

else:
    print("Failed to retrieve the webpage. Double check your connection or url provided. Thanks!")