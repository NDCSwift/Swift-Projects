# Define the base Character class representing a general RPG character
class Character:
    def __init__(self, name, race, role, strength, agility, intelligence):
        """
        Constructor for the Character class.
        Initializes a character with name, race, role, and stats (strength, agility, intelligence).
        """
        self.name = name  # Character's name
        self.race = race  # Character's race (e.g., Human, Elf, Orc)
        self.role = role  # Character's class (e.g., Warrior, Mage, Rogue)
        self.strength = strength  # Strength stat (used for physical attacks)
        self.agility = agility  # Agility stat (used for dodging)
        self.intelligence = intelligence  # Intelligence stat (used for magic)

    def display_stats(self):
        """Displays the character's attributes."""
        print(f"Character: {self.name}")
        print(f"Race: {self.race}")
        print(f"Class: {self.role}")
        print(f"Stats - STR: {self.strength}, AGI: {self.agility}, INT: {self.intelligence}\n")

    def attack(self):
        """Character attacks based on their strength."""
        print(f"{self.name} attacks with power {self.strength}!")

    def dodge(self):
        """Character dodges based on their agility."""
        print(f"{self.name} dodges with agility {self.agility}!")

# Define the Mage class that inherits from Character
class Mage(Character):
    def __init__(self, name, race, intelligence):
        """
        Constructor for the Mage subclass.
        Inherits from Character but defaults strength and agility while emphasizing intelligence.
        """
        super().__init__(name, race, "Mage", strength=3, agility=5, intelligence=intelligence)  
        # Uses 'super()' to call the constructor of the parent class (Character)

    def cast_spell(self):
        """Mage-specific method that represents casting a spell based on intelligence."""
        print(f"{self.name} casts a powerful spell with INT {self.intelligence}!")
        
        # This method demonstrates **polymorphism**—it extends functionality unique to Mage,
        # which is different from the attack method in the base class.

# Function to create a new character interactively
def create_character():
    """
    Prompts the user to input details for creating a new character.
    Uses user input to instantiate either a Mage or a generic Character.
    """
    name = input("Enter your character's name: ")
    race = input("Choose a race (Human, Elf, Orc): ")
    role = input("Choose a class (Warrior, Mage, Rogue): ")

    # Conditional logic to instantiate the correct class based on the role selection
    if role.lower() == "mage":
        intelligence = int(input("Enter intelligence stat: "))
        character = Mage(name, race, intelligence)  # Mage-specific instantiation
    else:
        strength = int(input("Enter strength stat: "))
        agility = int(input("Enter agility stat: "))
        intelligence = int(input("Enter intelligence stat: "))
        character = Character(name, race, role, strength, agility, intelligence)  # Generic character instantiation

    character.display_stats()  # Show the newly created character's stats
    return character  # Return the character object

# Example of instantiating a Mage character
mage = Mage("Gandalf", "Human", intelligence=12)  # Create a Mage instance
mage.display_stats()  # Display Mage attributes
mage.cast_spell()  # Demonstrate Mage-specific method

# Run the character creator for user input
player_character = create_character()  # Allow the player to create a character interactively

