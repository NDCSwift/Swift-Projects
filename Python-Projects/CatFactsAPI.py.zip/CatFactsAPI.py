import requests

url = "https://catfact.ninja/fact"
response = requests.get(url)

data = response.json()
print("Random Cat Fact:")
print(data["fact"])

url2 ="https://official-joke-api.appspot.com/random_joke"
respose2= requests.get(url2)
joke = respose2.json()
print(joke["setup"])
print(joke["punchline"])

# headers = {"Authorization": "Bearer YOUR_API_KEY"}
# response = requests.get("https://some-api.com/data", headers=headers)

# url = "https://some-api.com/data?api_key=YOUR_API_KEY"