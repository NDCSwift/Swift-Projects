# This script performs data analysis on a sales dataset.
# It includes data cleaning, filtering, sorting, aggregation, and visualization.

import pandas as pd  # Importing the Pandas library for data handling
import matplotlib.pyplot as plt  # Importing Matplotlib for data visualization

# Load dataset
file_path = "/Users/ncarpenter/Desktop/Python/Completed Examplees/sales_data.csv"  # Define the file path of the dataset
df = pd.read_csv(file_path)  # Read the CSV file into a Pandas DataFrame

# Convert the 'Date' column to datetime format for future time-based analysis
df["Date"] = pd.to_datetime(df["Date"])

# Data Cleaning
df.fillna(0, inplace=True)  # Fill missing values in the dataset with 0

# Filtering data
product_name = "Laptop"  # Define the product to filter
laptop_sales = df[df["Product"] == product_name]  # Filter the dataset to include only sales of the specified product

# Sorting data
df_sorted = df.sort_values(by="Revenue", ascending=False)  # Sort the dataset by Revenue in descending order

# Grouping and aggregating data
total_revenue = df.groupby("Product")["Revenue"].sum()  # Group data by Product and sum the Revenue for each product

# Optional: also analyze total units sold per product
total_units_sold = df.groupby("Product")["Sales"].sum()  # Group data by Product and sum total Sales

# Optional: get top 5 revenue days overall
top_revenue_days = df.groupby("Date")["Revenue"].sum().sort_values(ascending=False).head()  # Top 5 days by total revenue
print("Top 5 Revenue Days:")
print(top_revenue_days)

# Data Visualization: Total Revenue by Product
total_revenue.plot(kind='bar', color='skyblue')  # Create a bar chart to visualize total revenue by product
plt.title("Total Revenue by Product")  # Set the title of the chart
plt.xlabel("Product")  # Label the x-axis
plt.ylabel("Revenue ($)")  # Label the y-axis
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.tight_layout()  # Adjust layout for clarity
plt.show()  # Display the chart

# Data Visualization: Total Units Sold by Product
total_units_sold.plot(kind='bar', color='orange')  # Create a bar chart for units sold
plt.title("Total Units Sold by Product")  # Set the title of the chart
plt.xlabel("Product")  # Label the x-axis
plt.ylabel("Units Sold")  # Label the y-axis
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.tight_layout()  # Adjust layout for clarity
plt.show()  # Display the chart