from flask import Flask, jsonify  # Import Flask and a helper to return JSON

app = Flask(__name__)  # Create our Flask web application

@app.route("/")  # Route for the homepage
def home():
    return jsonify({"message": "Hello from your first Flask server!"})  # Return a JSON response

if __name__ == "__main__":  # Run the server only if this file is executed directly
    app.run(debug=True)  # Run with debug mode on (auto-reloads server when you save)