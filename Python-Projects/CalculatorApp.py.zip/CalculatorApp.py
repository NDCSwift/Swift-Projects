
def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multipy(x, y):
    return x * y

def divide(x, y):
    if  y == 0 :
        return "Error: Cannot divide by Zero!"
    return x / y

print("Select Operation:")
print("1. Add")
print("2. Subtract")
print("3. Multiply")
print("4. Divide")

choice = input("Enter Your Choice (1/2/3/4):")

num1 = float(input("Enter your first Number"))
num2 = float(input("Enter your second Number"))

if choice == '1':
    print(f"The result is: {add(num1, num2)}")
elif choice == '2':
    print(f"The result is {subtract(num1, num2)}")
elif choice == '3':
    print(f"The result is : {multipy(num1, num2)}")
elif choice == '4':
    result = divide(num1, num2)
    print(f"The result is : {result}")

else:
    print("Invalid input. please chose options 1,2,3,4!")