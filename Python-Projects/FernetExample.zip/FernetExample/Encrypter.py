# File Encryption and Decryption using Fernet (symmetric encryption)
# This script allows you to encrypt and decrypt files using a secret key.
# You can generate a new key, load it, and then use it to secure your files.

from cryptography.fernet import Fernet  # Import the Fernet class for symmetric encryption

# Function to generate a new secret key and write it to a file
def write_key():
    key = Fernet.generate_key()  # Generate a new Fernet key
    with open("secret.key", "wb") as key_file:  # Open 'secret.key' in write-binary mode
        key_file.write(key)  # Save the key to the file

# Uncomment the next line to generate a new key
# write_key()

 # Function to load the existing secret key from file
def load_key():
    return open("secret.key", "rb").read()  # Read and return the key in binary mode

 # Function to encrypt a file
def encrypt_file(filename):
    key = load_key()  # Load the encryption key
    fernet = Fernet(key)  # Create a Fernet object with the key

    with open(filename, "rb") as file:  # Open the file to encrypt in binary read mode
        original_data = file.read()  # Read the file contents

    encrypted_data = fernet.encrypt(original_data)  # Encrypt the file contents

    with open(filename, "wb") as file:  # Open the same file in binary write mode
        file.write(encrypted_data)  # Overwrite it with the encrypted data

 # Function to decrypt a file
def decrypt_file(filename):
    key = load_key()  # Load the decryption key
    fernet = Fernet(key)  # Create a Fernet object with the key

    with open(filename, "rb") as file:  # Open the file to decrypt in binary read mode
        encrypted_data = file.read()  # Read the encrypted data

    decrypted_data = fernet.decrypt(encrypted_data)  # Decrypt the data

    with open(filename, "wb") as file:  # Open the file again in binary write mode
        file.write(decrypted_data)  # Overwrite it with the decrypted contents

# Uncomment to encrypt the file named "example.txt"
encrypt_file("example.txt")

# Decrypt the file named "example.txt"
#decrypt_file("example.txt")

#Supported File Types
# Notes
# .txt, .csv, .json
# Plain text files encrypt smoothly.
# .jpg, .png, .gif
# Image files work fine, but cannot be opened/viewed while encrypted.
# .pdf, .docx, .xlsx
# Can be encrypted/decrypted, but corruption will occur if editing is attempted while encrypted.
# .mp3, .mp4, .zip
# Binary/media/archive files work too.
# .py, .js, etc.
# Source code files can be encrypted/decrypted, but shouldn’t be run while encrypted.
