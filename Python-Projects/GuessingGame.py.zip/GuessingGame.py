import random

number = random.randint(1, 10)

# guess =  int(input("Guess a number between 1 and 10"))

attempts = 0

while True:
    guess =  int(input("Guess a number between 1 and 10"))
    attempts += 1

    if guess == number:
        print(f"Congrats! You've gessed correctly in {attempts} tries!")
        break
    elif guess < number:
        print("Too low! and try again")
    else:
        print("Too High! try again")