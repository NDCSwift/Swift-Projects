import json  # Import the built-in module to work with JSON data
from datetime import datetime  # Import to generate current timestamps
import os  # Import to handle file paths safely across systems

# 📁 Dynamically find the path to the JSON file based on where this script is saved
# This ensures the script works no matter where it's run from
base_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory containing the script
json_path = os.path.join(base_dir, "products.json")  # Build the path to the input JSON file

# 📥 Load JSON with error handling to prevent crashes
try:
    with open(json_path, "r") as file:  # Open the file in read mode ("r") to load existing data
        data = json.load(file)  # Read and parse the JSON into a Python list
except json.JSONDecodeError as e:
    print("❌ Failed to load JSON:", e)
    exit()
except FileNotFoundError as e:
    print("❌ File not found:", e)
    exit()

# 🧹 Filter the data to remove products that are out of stock
filtered = [item for item in data if item["stock"] > 0]

# ✍️ Modify each remaining item with new fields:
# - Add a 'discounted' flag for electronics
# - Add a 'last_updated' date to show when the data was processed
for item in filtered:
    item["discounted"] = item["category"] == "electronics"  # True if it's an electronics item
    item["last_updated"] = datetime.now().strftime("%Y-%m-%d")  # Add the current date

# ➕ Append a new product to the list as an example of adding to a JSON array
new_item = {
    "id": 4,
    "name": "Sticky Notes",
    "price": 1.99,
    "category": "stationery",
    "stock": 120,
    "discounted": False,
    "last_updated": datetime.now().strftime("%Y-%m-%d")
}
filtered.append(new_item)

# 💾 Save the modified list to a new JSON file in the same directory
# This avoids overwriting the original and keeps the structure clean
updated_path = os.path.join(base_dir, "updated_products.json")
with open(updated_path, "w") as file:  # Open the file in write mode ("w") to overwrite or create a new JSON file
    json.dump(filtered, file, indent=2)  # Save with indentation for readability

# ✅ Let the user know it completed successfully
print("✅ Cleaned data saved to 'updated_products.json'")
