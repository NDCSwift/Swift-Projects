//
//  SettingsViewController.swift
//  SegueExamples
//
//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import Foundation
import UIKit

class SettingsViewController: UIViewController {

    // Outlet for the background color switch
    @IBOutlet weak var bgSwitch: UISwitch!
    
    // Outlet for the button to change background color in the first view controller
    @IBOutlet weak var blackBackground: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Additional setup can be done after the view has loaded
    }

    // Action method triggered when the background switch is toggled
    @IBAction func bgSwitchChange(_ sender: UISwitch) {
        // Change the background color based on the switch state
        if sender.isOn {
            // Set the background color to green if switch is on
            self.view.backgroundColor = UIColor.green
        } else {
            // Set the background color to cyan if switch is off
            self.view.backgroundColor = UIColor.cyan
        }
    }

    // Action method triggered when the button is pressed to change the background of the first view controller
    @IBAction func changeFirstVCBG(_ sender: UIButton) {
        // Access the first view controller in the navigation stack
        let firstViewController = navigationController?.viewControllers.first
        
        // Change the background color of the first view controller to black
        firstViewController?.view.backgroundColor = UIColor.black
    }
}
