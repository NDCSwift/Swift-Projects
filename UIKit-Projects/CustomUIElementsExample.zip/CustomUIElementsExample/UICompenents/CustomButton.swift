//
    // Project: CustomUIElementsExample
    //  File: CustomButton.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    
import UIKit

enum ButtonStyle {
    case filled, outlined
}

class CustomButton: UIButton {
    init(title: String, style: ButtonStyle) {
        super.init(frame: .zero)
        setTitle(title, for: .normal)
        setupStyle(style)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func setupStyle(_ style: ButtonStyle) {
        switch style {
        case .filled:
            backgroundColor = .systemBlue
            setTitleColor(.white, for: .normal)
        case .outlined:
            backgroundColor = .clear
            layer.borderWidth = 2
            layer.borderColor = UIColor.systemBlue.cgColor
            setTitleColor(.systemBlue, for: .normal)
        }
    }
}
