//
    // Project: CustomUIElementsExample
    //  File: ViewController.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import UIKit

class ViewController: UIViewController {
    
    let filledButton = CustomButton(title: "Filled", style: .filled)
    let outlinedButton = CustomButton(title: "Outlined", style: .outlined)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI() // ✅ Call the function to add buttons
    }

    private func setupUI() {
        view.backgroundColor = .white // ✅ Ensure we see the buttons

        // **Step 1: Disable autoresizing constraints**
        filledButton.translatesAutoresizingMaskIntoConstraints = false
        outlinedButton.translatesAutoresizingMaskIntoConstraints = false
        
        // **Step 2: Add buttons to the view**
        view.addSubview(filledButton)
        view.addSubview(outlinedButton)

        // **Step 3: Add Auto Layout Constraints**
        NSLayoutConstraint.activate([
            // Center the filled button
            filledButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            filledButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100),
            filledButton.widthAnchor.constraint(equalToConstant: 200),
            filledButton.heightAnchor.constraint(equalToConstant: 50),

            // Position outlined button below filled button
            outlinedButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            outlinedButton.topAnchor.constraint(equalTo: filledButton.bottomAnchor, constant: 20),
            outlinedButton.widthAnchor.constraint(equalToConstant: 200),
            outlinedButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
}

