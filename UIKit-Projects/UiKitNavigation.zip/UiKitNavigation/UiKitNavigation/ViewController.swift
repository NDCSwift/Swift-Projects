//
    // Project: UiKitNavigation
    //  File: ViewController.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var loginField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

//    let modalVC = ModalViewController()
//    modalVC.modalPresentationStyle = .automatic
//    present(modalVC, animted: true, completion: nil)
    
    @IBAction func loginButtonPressed(_ sender: UIButton) {
        guard passwordField.text == "1234" else {return}
        let homeVC = HomeViewController()
        homeVC.username = loginField.text ?? "User"
        navigationController?.pushViewController(homeVC, animated: true)
    }
    

}

