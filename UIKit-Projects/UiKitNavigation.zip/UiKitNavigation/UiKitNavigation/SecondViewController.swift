import UIKit

class SecondViewController: UIViewController {
    var username: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBlue
        title = "Second VC"
    }
}