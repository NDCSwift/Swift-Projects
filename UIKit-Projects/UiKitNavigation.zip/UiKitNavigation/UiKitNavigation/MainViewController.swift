//
    // Project: UiKitNavigation
    //  File: MainViewController.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//    
//    @IBAction func showModalTapped(_ sender: UIButton) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let modalVC = storyboard.instantiateViewController(withIdentifier: "ModalViewController")
//        modalVC.modalPresentationStyle = .pageSheet
//        present(modalVC, animated: true, completion: nil)
//    }
    
    
//    
//    @IBAction func showSheetTapped(_ sender: UIButton) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let sheetVC = storyboard.instantiateViewController(withIdentifier: "SheetViewController")
//        
//        if let sheet = sheetVC.sheetPresentationController{
//            sheet.detents = [.medium(), .large()]
//            sheet.prefersGrabberVisible = true
//        }
//        present(sheetVC, animated: true)
//    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
