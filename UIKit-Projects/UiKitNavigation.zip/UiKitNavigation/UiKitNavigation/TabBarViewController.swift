import UIKit

class TabBarViewController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let vc1 = FirstViewController()
        vc1.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 0)
        let vc2 = SecondViewController()
        vc2.tabBarItem = UITabBarItem(tabBarSystemItem: .contacts, tag: 1)
        viewControllers = [vc1, vc2]
    }
}