//
    // Project: UiKitNavigation
    //  File: PageViewController.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import UIKit

class PageViewController: UIPageViewController, UIPageViewControllerDataSource {
    
    let pages = [
        PageContentViewController(text: "Page 1"),
        PageContentViewController(text: "Page 2"),
        PageContentViewController(text: "Page 3")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        dataSource = self
        setViewControllers([pages[0]], direction: .forward, animated: true)
        // Do any additional setup after loading the view.
    }
    
    func pageViewController(_ pvc: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let index = pages.firstIndex(of: viewController as! PageContentViewController), index > 0 else { return nil }
        return pages[index - 1]
    }
    
    func pageViewController(_ pvc: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let index = pages.firstIndex(of: viewController as! PageContentViewController), index < pages.count - 1 else { return nil }
        return pages [index + 1]
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
