//
//  ColloectionViewController.swift
//  Collections
//
//  Created by Noah Carpenter on 2024-11-03.
//

import Foundation
import UIKit

class CollectionViewController : ViewController, UICollectionViewDataSource {
    
    let items = ["Item1", "Item2","Item3", "Item4"]
    
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        //start up code goes here
        collectionView.dataSource = self
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath)
        cell.contentView.backgroundColor = .lightGray
        return cell
    }
    
    
    
    
    
}
