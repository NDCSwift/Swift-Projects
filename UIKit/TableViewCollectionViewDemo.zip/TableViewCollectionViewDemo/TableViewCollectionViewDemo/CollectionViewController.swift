//
//  CollectionViewController.swift
//  TableViewCollectionViewDemo
//
//  Created by Noah Carpenter on 2024-11-03
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger
//

import Foundation
import UIKit

// CollectionViewController is responsible for displaying a collection of items in a grid format
class CollectionViewController: UIViewController, UICollectionViewDataSource{
  
    // Array of SF Symbols to display in the collection view cells
    let items = ["star.fill", "moon.fill", "flag.fill","bell.fill"]
    
    // Called when the view is loaded, setting up the collection view data source
    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup code goes here
        collectionView.dataSource = self // Set the data source for the collection view
    }
    
    // Outlet to the UICollectionView from the storyboard
    @IBOutlet weak var collectionView: UICollectionView!
    
    // Return the number of items in the collection (based on the array count)
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    // Configure and return each cell with an SF Symbol image for the collection view
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath)
        
        // Get the image view inside the cell and set the SF Symbol image
        if let imageView = cell.contentView.subviews.first as? UIImageView {
            // Set the image of the SF Symbol based on the current index
            imageView.image = UIImage(systemName: items[indexPath.row])
            // Set the image view frame
            imageView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
            // Set the symbol color to system pink
            imageView.tintColor = .systemPink
        }
        
        return cell
    }
}
