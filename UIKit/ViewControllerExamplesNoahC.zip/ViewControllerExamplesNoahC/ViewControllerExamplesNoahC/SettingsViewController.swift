//
//  SettingsViewController.swift
//  ViewControllerExamplesNoahC
//
//  Created by Noah Carpenter on 2024-04-08.
//

import Foundation
import UIKit

class SettingsViewController: UIViewController {

    
    @IBOutlet weak var bgSwitch: UISwitch!
    
    
    @IBOutlet weak var bgBlack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func bgSwitchToggle(_ sender: UISwitch) {
        
        if sender.isOn{
            self.view.backgroundColor = UIColor.red
            
        }else{
            self.view.backgroundColor = UIColor.cyan
            
        }
        
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        
        let firstViewController = navigationController?.viewControllers.first
        
        firstViewController.self?.view.backgroundColor = UIColor.black
        
    }
    
    
}

