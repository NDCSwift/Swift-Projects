//  ViewController.swift
//  NotificationsExample
//
//  Created by Noah Carpenter on 2024-04-12.
//
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

import UIKit

// MARK: - ViewController

/// A view controller that displays a button to show alerts with multiple actions.
/// Demonstrates how to create and present `UIAlertController` with various actions.
class ViewController: UIViewController {
    
    // MARK: - Lifecycle Methods
    
    /// Called after the controller's view is loaded into memory.
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create a UIButton programmatically.
        // Alternatively, you can use Interface Builder to add buttons, but this shows how to hard-code it.
        let button = UIButton(frame: CGRect(x: 100, y: 200, width: 200, height: 50))
        button.backgroundColor = .blue  // Set the button's background color to blue.
        button.setTitle("Show Alert", for: .normal)  // Set the button's title.
        button.addTarget(self, action: #selector(showAlert), for: .touchUpInside)  // Add an action to the button.
        self.view.addSubview(button)  // Add the button to the view's hierarchy.
    }
    
    // MARK: - Action Methods
    
    /// Presents an alert with multiple actions when the button is tapped.
    @objc func showAlert() {
        // Create the alert controller with a title and message.
        let alertController = UIAlertController(title: "Make a Choice", message: "Select an option", preferredStyle: .alert)
        
        // Define the "Yes" action with a closure to handle the response.
        let yesAction = UIAlertAction(title: "Yes", style: .default) { [weak self] action in
            self?.showFollowUpAlert(message: "User selected Yes")
        }
        alertController.addAction(yesAction)  // Add the "Yes" action to the alert.
        
        // Define the "No" action with a closure to handle the response.
        let noAction = UIAlertAction(title: "No", style: .default) { action in
            print("User chose No")  // Log the user's choice.
        }
        alertController.addAction(noAction)  // Add the "No" action to the alert.
        
        // Define the "Maybe" action with a closure to handle the response.
        let maybeAction = UIAlertAction(title: "Maybe", style: .default) { action in
            print("User chose Maybe")  // Log the user's choice.
        }
        alertController.addAction(maybeAction)  // Add the "Maybe" action to the alert.
        
        // If running on iPad, configure the popover presentation to avoid crashes.
        if let popoverPresentationController = alertController.popoverPresentationController {
            popoverPresentationController.sourceView = self.view  // Use the view controller's main view as the source view.
            popoverPresentationController.sourceRect = self.view.bounds  // Present from the center of the screen.
            popoverPresentationController.permittedArrowDirections = []  // No arrow for the popover.
        }
        
        // Present the alert controller animated.
        self.present(alertController, animated: true, completion: nil)
    }
    
    /// Presents a follow-up alert with a custom message.
    /// - Parameter message: The message to display in the follow-up alert.
    func showFollowUpAlert(message: String) {
        // Create another alert controller for the follow-up message.
        let followUpAlert = UIAlertController(title: "Result", message: message, preferredStyle: .alert)
        let closeAction = UIAlertAction(title: "Close", style: .cancel, handler: nil)  // Define a "Close" action.
        followUpAlert.addAction(closeAction)  // Add the "Close" action to the follow-up alert.
        
        // Present the follow-up alert animated.
        self.present(followUpAlert, animated: true, completion: nil)
    }
}
