//
//  ChatPrototypeApp.swift
//  ChatPrototype
//
//  Created by Noah Carpenter on 2024-12-16.
//

import SwiftUI

@main
struct ChatPrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
