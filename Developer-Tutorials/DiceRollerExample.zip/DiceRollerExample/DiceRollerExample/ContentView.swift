//  Created by Noah Carpenter
//  🐱 Follow me on YouTube! 🎥
//  https://www.youtube.com/@NoahDoesCoding97
//  Like and Subscribe for coding tutorials and fun! 💻✨
//  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
//  Dream Big, Code Bigger

// Import SwiftUI framework for UI components
import SwiftUI

// Main content view for the Dice Roller app
struct ContentView: View {
    // State property to track the number of dice (1-5)
    @State private var numberOfDice: Int = 1
    
    var body: some View {
        // Main vertical stack container
        VStack {
            // Title of the app
            Text("Dice Roller")
                .font(.largeTitle.lowercaseSmallCaps()) // Stylized text with small caps
                .bold()
                .foregroundStyle(.white)
            
            // Horizontal stack for displaying dice
            HStack{
                // Creates multiple DiceView instances based on numberOfDice
                ForEach(1...numberOfDice, id: \.description){ _ in 
                    DiceView()
                }
            }
            
            // Controls for adding/removing dice
            HStack{
                // Remove dice button
                Button("Remove Dice", systemImage: "minus.circle.fill"){
                    withAnimation{ // Animate the dice removal
                        numberOfDice -= 1
                    }
                }
                .disabled(numberOfDice == 1) // Disable when only one die remains
                
                // Add dice button
                Button("Add Dice", systemImage: "plus.circle.fill"){
                    withAnimation{ // Animate the dice addition
                        numberOfDice += 1
                    }
                }
                .disabled(numberOfDice == 5) // Disable when maximum (5) dice reached
                
            }
            .padding()
            .labelStyle(.iconOnly) // Show only icons for buttons
            .font(.title)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity) // Fill available space
        .background(.appBackground) // Custom background color
        .tint(.white) // Tint color for interactive elements
    }
}

// Preview provider for SwiftUI canvas
#Preview {
    ContentView()
}
