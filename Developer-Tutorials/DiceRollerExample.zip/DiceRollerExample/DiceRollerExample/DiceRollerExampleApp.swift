//
//  DiceRollerExampleApp.swift
//  DiceRollerExample
//
//  Created by Noah Carpenter on 2025-01-02.
//

import SwiftUI

@main
struct DiceRollerExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
