//
    // Project: Alphabetizer
    //  File: Message.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import Foundation

enum Message: String{
    case instructions = "Place the tiles in the alphabetical order"
    case tryAgain = "Try again 😅"
    case youWin = "You win! 🏆"
}
