//
    // Project: Alphabetizer
    //  File: Alphabetizer.swift
    //  Created by Noah Carpenter
    //  🐱 Follow me on YouTube! 🎥
    //  https://www.youtube.com/@NoahDoesCoding97
    //  Like and Subscribe for coding tutorials and fun! 💻✨
    //  Fun Fact: Cats have five toes on their front paws, but only four on their back paws! 🐾
    //  Dream Big, Code Bigger
    

import Foundation

@Observable
class Alphabetizer{
    
    private let tileCount = 3
    private var vocab: Vocabulary
    
    var tiles = [Tile]()
    var score = 0
    var message: Message = .instructions
    
    init(vocab: Vocabulary = .landAnimals){
        self.vocab = vocab
        startNewGame()
    }
    
  
    
    /// checks if tiles are in alphabetical order
    func submit(){
       // Check if the tiless are alphabetized
        let userSortedTiles = tiles.sorted {
            $0.position.x < $1.position.x
        }
        
        let alphebitcallySortedTiles = tiles.sorted {
            $0.word.lexicographicallyPrecedes($1.word)
        }

        
        let isAlphabetized = userSortedTiles == alphebitcallySortedTiles
        
        // if alphabetized, increment the score
        if isAlphabetized{
            score += 1
        }
        // Update the message to win or lose
        message = isAlphabetized ? .youWin : .tryAgain

        // Flip over correct tiles
        for (tile, correctTile) in zip(userSortedTiles, alphebitcallySortedTiles) {
            let tileIsAlphabetized = tile == correctTile
            tile.flipped = tileIsAlphabetized
        }

        Task{ @MainActor in
            // Delay 2 seconds
            try await Task.sleep(for: .seconds(2))
            
            // If alphabetized, generate new tiles
            if isAlphabetized {
               
                startNewGame()
            }
            
            // Flip tiles back to words
            for tile in tiles {
                tile.flipped = false
            }
            
            // Display instructions
            message = .instructions
        }
    }
    
    // MARK: private implementation
    
    /// updates "tiles" with a new set of unalphabatized words
    private func startNewGame(){
        let newWords = vocab.selectRandomWords(count: tileCount)
        if tiles.isEmpty{
            for word in newWords {
                tiles.append(Tile(word: word))
            }
        } else {
            // assign new words to existing tiles
            for (tile, word) in zip(tiles, newWords){
                tile.word = word
            }
        }
        
    }
    
}
