import SwiftUI

struct LaunchScreenView: View {
    // Animation properties
    @State private var isAnimating = false
    @State private var gradientRotation = 0.0
    
    // Gradient colors
    let gradient = LinearGradient(
        colors: [.blue, .purple, .pink],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    
    var body: some View {
        ZStack {
            // Animated background
            gradient
                .rotationEffect(.degrees(gradientRotation))
                .scaleEffect(isAnimating ? 1.2 : 1.0)
                .blur(radius: isAnimating ? 5 : 0)
                .animation(
                    .easeInOut(duration: 2.0)
                    .repeatForever(autoreverses: true),
                    value: isAnimating
                )
            
            // App title
            Text("ScoreKeeper")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.white)
                .opacity(isAnimating ? 1 : 0)
                .scaleEffect(isAnimating ? 1 : 0.5)
                .animation(.easeIn(duration: 1.0), value: isAnimating)
        }
        .ignoresSafeArea()
        .onAppear {
            isAnimating = true
            withAnimation(.linear(duration: 10.0).repeatForever(autoreverses: false)) {
                gradientRotation = 360.0
            }
        }
    }
}

#Preview {
    LaunchScreenView()
}

