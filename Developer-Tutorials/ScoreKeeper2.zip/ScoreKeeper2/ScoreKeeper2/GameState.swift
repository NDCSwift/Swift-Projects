//
//  GameState.swift
//  ScoreKeeper2
//
//  Created by Noah Carpenter on 2025-01-07.
//

enum GameState{
    case setup
    case playing
    case gameOver
}
