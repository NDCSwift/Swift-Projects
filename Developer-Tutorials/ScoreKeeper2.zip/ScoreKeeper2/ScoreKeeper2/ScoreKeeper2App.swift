//
//  ScoreKeeper2App.swift
//  ScoreKeeper2
//
//  Created by Noah Carpenter on 2025-01-07.
//

import SwiftUI

@main
struct ScoreKeeper2App: App {
    // State to control launch screen visibility
    @State private var isShowingLaunchScreen = true
    
    var body: some Scene {
        WindowGroup {
            if isShowingLaunchScreen {
                LaunchScreenView()
                    .onAppear {
                        // Dismiss launch screen after 3 seconds
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                            withAnimation {
                                isShowingLaunchScreen = false
                            }
                        }
                    }
            } else {
                ContentView()
            }
        }
    }
}
