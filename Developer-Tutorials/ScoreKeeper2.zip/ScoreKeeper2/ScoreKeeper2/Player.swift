//
//  Player.swift
//  ScoreKeeper2
//
//  Created by Noah Carpenter on 2025-01-07.
//

import Foundation

struct Player: Identifiable {
   let id = UUID()
    
    
    
    var name: String
    var score: Int
    
}

extension Player: Equatable{
    static func == (lhs: Player, rhs: Player) -> Bool {
        lhs.name == rhs.name && lhs.score == rhs.score
    }
}
