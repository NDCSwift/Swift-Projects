//
//  ScoreKeeper2Tests.swift
//  ScoreKeeper2Tests
//
//  Created by Noah Carpenter on 2025-01-07.
//

import Testing
@testable import ScoreKeeper2


struct ScoreKeeper2Tests {

    @Test("Reset player scores", arguments: [0, 10, 20])
    func resetScores(to newValue: Int) async throws {
        var scoreboard = Scoreboard( players: [
            Player(name: "Elisha", score: 0),
            Player(name: "Andre", score: 5)
            
        ])
        scoreboard.resetScores(to: 0)
        
        for player in scoreboard.players{
            #expect(player.score == 0)
        }
    }
    
    @Test("Highest Score Wins")
    func highestScoreWins() {
        let scoreboard = Scoreboard(players: [
            Player(name: "elisha", score: 0),
            Player(name: "Andre", score: 4),
        ],
                                    state: .gameOver,
                                    doesHighestScoreWin: true
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Andre", score: 4)])
    }
    
    @Test("Lowest Score Wins")
    func lowestScoreWins(){
        let scoreboard = Scoreboard(players: [
            Player(name: "Elisha", score: 0),
            Player(name: "Andre", score: 4),
        ],
                                    state: .gameOver,
                                    doesHighestScoreWin: false
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Elisha", score: 0)])
    }

}
